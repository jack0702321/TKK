SET logfile=RptMainLog%date:~0,4%%date:~5,2%%date:~8,2%.log
ECHO �}�l�ɶ�:%date% %time% > %logfile%
java -jar RptMain.jar -cp *; -encoding UTF8 >> %logfile%