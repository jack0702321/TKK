
public class RptMain {
	public static void main(String[] args) {
		WeekReportBig5 wRpt = new WeekReportBig5();
		wRpt.WeekRpt();
	}
}
