package com.ubot.kyc.comm;

public class MailServiceThread extends Thread {

	public MailServiceThread(String from,String to,String subject,String body){
		this.from = from;
		this.to = to;
		this.subject = subject;
		this.body = body;
	}
	
	public MailServiceThread(String from,String to,String subject,String body,String attach){
		this.from = from;
		this.to = to;
		this.subject = subject;
		this.body = body;
		this.attach = attach;
	}
			
	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	String from;
	String to;
	String subject;
	String body;
	String attach="";
	
	
	 public void run() { // override Thread's run()
		 MailServices mail = new MailServices();
		 if (attach.equals("")){
			 //System.out.println("no attach");
			 mail.send(from, to, subject, body);
		 } else {
			 //System.out.println("with attach " + attach);
			 mail.send(from, to, subject, body, attach);
		 }
	  }
}
