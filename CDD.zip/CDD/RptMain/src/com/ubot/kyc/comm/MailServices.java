package com.ubot.kyc.comm;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;

public class MailServices {

	private static String server = "";
	//private static String from = "";

	static void init() {
		
		Properties properties = new Properties();
		String configFile = "MailServices.properties";
			try {
				properties.load(new FileInputStream(configFile));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("File Not found (MailServices.properties)");
				e.printStackTrace();
			} catch (IOException e) {
				System.out.println("IOException");
				e.printStackTrace();
			}
		
		server = properties.getProperty("SERVER").trim();
		
	}
	
	public String send(String from, String to, String subject, String body) {
		init();
		String result = "";
		try {
			Properties props = System.getProperties();
			props.put("mail.smtp.host", server);
			
			Session session = Session.getDefaultInstance(props, null);
			// -- Create a new message --
			Message msg = new MimeMessage(session);

			// -- Set the FROM fields --
			msg.setFrom(new InternetAddress(from));

			// -- Set the TO fields --
			msg.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(to, false));
			// -- We could include CC recipients too --
			// if (cc != null)
			// msg.setRecipients(Message.RecipientType.CC
			// ,InternetAddress.parse(cc, false));

			// -- Set the subject and body text --
			// msg.setSubject(subject);
			String cSubject = MimeUtility.encodeWord(subject, "BIG5", "B");
			// ystem.out.println("decode subject : " + cSubject);
			msg.setSubject(cSubject);

			msg.setText(body);

			/*
			 * System.out.println("from    : " + from);
			 * System.out.println("to      : " + to);
			 * System.out.println("subject : " + subject);
			 * System.out.println("body    : " + body);
			 */

			// -- Set some other header information --
			// msg.setHeader("X-Mailer", "LOTONtechEmail");

			msg.setSentDate(new Date());

			// -- Send the message --
			Transport.send(msg);

			// System.out.println("Message sent OK.");
			result = "OK";
		} catch (Exception ex) {
			result = ex.getMessage();			
			ex.printStackTrace();
		} finally {
			
		}
		return result;

	}

	public void send(String from, String to, String subject, String body, String attach) {
		init();
		java.util.Properties props = System.getProperties();
		props.put("mail.host", server);
		props.put("mail.transport.protocol", "smtp");
		boolean sessionDebug = false;
		javax.mail.Session mailSession = javax.mail.Session.getDefaultInstance(
				props, null);
		mailSession.setDebug(sessionDebug);
		Message msg = new MimeMessage(mailSession);
		try {
			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(to, false));

			// msg.setSubject(subject);
			String cSubject = MimeUtility.encodeWord(subject, "BIG5", "B");
			msg.setSubject(cSubject);

			msg.setSentDate(new Date());
			// msg.setText(messageText);

			// Transport.send(msg);
			MimeBodyPart messageBodyPart = new MimeBodyPart();

			// fill message
			messageBodyPart.setText(body);

			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);

			// Part two is attachment
			messageBodyPart = new MimeBodyPart();
			DataSource source = new FileDataSource(attach);
			messageBodyPart.setDataHandler(new DataHandler(source));
			messageBodyPart.setFileName(attach);
			multipart.addBodyPart(messageBodyPart);

			// Put parts in message
			msg.setContent(multipart);
			//System.out.println("Sending...");
			// Send the message
			Transport.send(msg);
			//System.out.println("SEND");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
