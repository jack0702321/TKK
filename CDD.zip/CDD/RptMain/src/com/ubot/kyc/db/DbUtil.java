package com.ubot.kyc.db;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DbUtil {

	public Connection conn = getConnection();

	public static Connection getConnection() {
		
		Properties properties = new Properties();
		String configFile = "DbUtil.properties";

		
		try {
			properties.load(new FileInputStream(configFile));
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		String dbServer = properties.getProperty("DBSERVER").trim();
		String ip = properties.getProperty("IP").trim();
		String port = properties.getProperty("PORT").trim();
		// int portNo = Integer.parseInt(port);
		String dbName = properties.getProperty("DBNAME").trim();
		String user = properties.getProperty("USER").trim();
		String pass = properties.getProperty("PASSWORD").trim();
		String driverName = properties.getProperty("DRIVER");

		Connection conn = null;
		
		try {
			Class.forName(driverName);
			// String dbURL =
			// "jdbc:sqlserver://172.16.68.82;DatabaseName=Verificationdata";
			String dbURL = String.format("jdbc:%s://%s:%s;DatabaseName=%s", dbServer, ip, port, dbName);
			conn = DriverManager.getConnection(dbURL, user, pass);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return conn;
	}

}