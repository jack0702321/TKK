/* KYC107005	20181109	fix dbcp usage									Steven Hsieh
 * KYC108002	20190222	查詢時行員或簽核主管被刪除時，不會顯示之錯誤	Steven Hsieh
 * KYC108009	20180617	add Exception logger 							Alex Tsai
 				20190520	增加RA欄位										Chia-Cheng Hsu
 */
package com.ubot.kyc.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FlowLogDao {
	public boolean existEndTime(String cId, String date, Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM FLOWLOG WHERE CID = ? AND USTATUS = ? AND ENDTIME >= ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			pstmt.setString(2, "9R");
			pstmt.setString(3, date);
			rs = pstmt.executeQuery(); 
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;
	}
}
