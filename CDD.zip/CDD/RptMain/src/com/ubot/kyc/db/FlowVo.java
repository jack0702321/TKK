/*
 * KYC108009	20190520	增加RA欄位	Chia-Cheng Hsu
*/
package com.ubot.kyc.db;

public class FlowVo {	
	
	
	private String cId;     // 客戶統編	
	private String startTime; // 開始日期時間
	private String branch; // 分行代碼
	private String uId;     // 經辦
	private String uTime; // 經辦修改時間
	private String sId; // 主管
	private String sTime; //  主管修改時間
	private String uStatus; // 狀態
	private String endTime; //  結束日期時間
	private String remark; //	備註
	private String mId; // 單位主管
	private String mTime; //  單位主管修改時間
	private String mRemark; //	單位主管備註
	private String RA; //	風險評級/分數
	
	

	public FlowVo() {
		super();
	}

	public FlowVo(String cId,String startTime,String branch,String uId,
			String uTime,String sId,String sTime,String uStatus,String endTime, 
			String remark,String mId,String mTime,String mRemark,String RA) {
		super();
		this.cId = cId;
		this.startTime = startTime;
		this.branch = branch;
		this.uId = uId;
		this.uTime = uTime;
		this.sId = sId;
		this.sTime = sTime;
		this.uStatus = uStatus;
		this.endTime = endTime;
		this.remark = remark;
		this.mId = mId;
		this.mTime = mTime;
		this.mRemark = mRemark;
		this.RA = RA;
	}

	public String getcId() {
		return cId;
	}



	public void setcId(String cId) {
		this.cId = cId;
	}



	public String getStartTime() {
		return startTime;
	}



	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}



	public String getBranch() {
		return branch;
	}



	public void setBranch(String branch) {
		this.branch = branch;
	}



	public String getuId() {
		return uId;
	}



	public void setuId(String uId) {
		this.uId = uId;
	}



	public String getuTime() {
		return uTime;
	}



	public void setuTime(String uTime) {
		this.uTime = uTime;
	}



	public String getsId() {
		return sId;
	}



	public void setsId(String sId) {
		this.sId = sId;
	}



	public String getsTime() {
		return sTime;
	}



	public void setsTime(String sTime) {
		this.sTime = sTime;
	}



	public String getuStatus() {
		return uStatus;
	}



	public void setuStatus(String uStatus) {
		this.uStatus = uStatus;
	}



	public String getEndTime() {
		return endTime;
	}



	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}



	public String getRemark() {
		return remark;
	}



	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
	
	public String getmId() {
		return mId;
	}

	public void setmId(String mId) {
		this.mId = mId;
	}

	public String getmTime() {
		return mTime;
	}

	public void setmTime(String mTime) {
		this.mTime = mTime;
	}

	public String getmRemark() {
		return mRemark;
	}

	public void setmRemark(String mRemark) {
		this.mRemark = mRemark;
	}

	public String getRA() {
		return RA;
	}

	public void setRA(String RA) {
		this.RA = RA;
	}

		
}
