/*
 * KYC108005	20190328	增加國外郵遞區號					Steven Hsieh
 * KYC108006	20190528	新增開戶日	Alex Tsai
 * KYC108009	20190422	增加欄位CRS（稅務居住者身分聲明）、ppNum（護照號碼）、ppDay（發照日）、OBU（是否為OBU客戶）、four（客戶股權（出資）結構是否超過3層（含））	Alex Tsai
				20190520	增加RA欄位	Chia-Cheng Hsu	
				20190621	增加出生地城市，國內外電話標記、最後編輯時間	Steven Hsieh
 * KYC108014	20190830	增加未提供職業/行業標記					Steven Hsieh
 * KYC109004	20191101	新增職稱其他、資本額、戶籍地址里		Steven Hsieh
*/
package com.ubot.kyc.db;

public class H_CustVo {
	private String cId;
	private String idType;
	private String bRFlag;
	private String bRRFlag;
	private String name;
	private String nCRFlag;
	private String nCRLink;
	private String nC993;
	private String nC993Data;
	private String eName;
	private String eNCRFlag;
	private String eNCRLink;
	private String eNC993;
	private String eNC993Data;
	private String idDFlag;
	private String idDO;
	private String idDLink;
	private String comT;
	private String comTO;
	private String nation;
	private String nationO;
	private String birthP;
	private String birthPO;
	private String birthD;
	private String marrFlag;
	private String marrO;
	private String eduFlag;
	private String eduO;
	private String job;
	private String jobO;
	private String jobEx;
	private String jobCom;
	private String sarUni;
	private String posFlag;
	private String posO;
	private String posName;
	private String bConFlag;
	private String cAmount;
	private String sY;
	private String iPY;
	private String rPY;
	private String bill;
	private String homeAddFlag;
	private String homeO;
	private String homeAdd;
	private String homeZip;
	private String homeCity;
	private String homeArea;
	private String homeStreet;
	private String homeLane;
	private String homeAly;
	private String homeNum;
	private String homeOf;
	private String homeFlr;
	private String homeEtc;
	private String mailAddFlag;
	private String mailO;
	private String mailAdd;
	private String mailZip;
	private String mailCity;
	private String mailArea;
	private String mailStreet;
	private String mailLane;
	private String mailAly;
	private String mailNum;
	private String mailOf;
	private String mailFlr;
	private String mailEtc;
	private String liveAddFlag;
	private String liveO;
	private String liveAdd;
	private String liveZip;
	private String liveCity;
	private String liveArea;
	private String liveStreet;
	private String liveLane;
	private String liveAly;
	private String liveNum;
	private String liveOf;
	private String liveFlr;
	private String liveEtc;
	private String comTelH;
	private String comTel;
	private String comTelExt;
	private String cell;
	private String dayTelH;
	private String dayTel;
	private String dayTelExt;
	private String nightTelH;
	private String nightTel;
	private String nightTelExt;
	private String homeTelH;
	private String homeTel;
	private String faxH;
	private String fax;
	private String email;
	private String fatca;
	private String iAMFlag;
	private String iAMO;
	private String bRPFlag;
	private String bRPO;
	private String inAmount;
	private String inTimes;
	private String outAmount;
	private String outTimes;
	private String bSFlag;
	private String bS929RES;	
	private String lTD;
	private String comBS;
	private String comBSP;
	private String comBSA;
	private String shBS;
	private String shBSP;
	private String shBSA;
	private String specFlag;
	private String stockC;
	private String stockEx;
	private String stockCom;
	private String bTypeChk;
	private String comM;
	private String spt;
	private String tof;
	private String op;
	private String abnFlag;
	private String uId;
	private String uOpnion;
	private String uRemark;
	private String sId;
	private String sRemark;
	private String cDateTime;
	private String editTime;
	private String mPath;
	private String homeAddZip;
	private String mailAddZip;
	private String liveAddZip;
	private String openTime;
	private String crs;
	private String obu;
	private String four;
	private String pPNum;
	private String pPDay;
	
	private String birthPC;
	private String comTelFlag;
	private String comTelO;
	private String cellFlag;
	private String cellO;
	private String homeTelFlag;
	private String homeTelO;
	private String dayTelFlag;
	private String dayTelO;
	private String nightTelFlag;
	private String nightTelO;
	private String birthPOC;
	private String homeVil;
	
	private String mId;
	private String mRemark;
	private String rARTime;
	private String rARank;
	private String rAScore;
	private String rANTime;
	private String rKYCTime;
	private String raReason;
	
	private String branch;
	private String accClsDate;
	private String accClsMark;	
	
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getAccClsDate() {
		return accClsDate;
	}
	public void setAccClsDate(String accClsDate) {
		this.accClsDate = accClsDate;
	}
	public String getAccClsMark() {
		return accClsMark;
	}
	public void setAccClsMark(String accClsMark) {
		this.accClsMark = accClsMark;
	}
	public String getRaReason() {
		return raReason;
	}
	public void setRaReason(String raReason) {
		this.raReason = raReason;
	}
	public String getrKYCTime() {
		return rKYCTime;
	}
	public void setrKYCTime(String rKYCTime) {
		this.rKYCTime = rKYCTime;
	}
	public String getBirthPOC() {
		return birthPOC;
	}
	public void setBirthPOC(String birthPOC) {
		this.birthPOC = birthPOC;
	}
	public String getBirthPC() {
		return birthPC;
	}
	public void setBirthPC(String birthPC) {
		this.birthPC = birthPC;
	}
	public String getComTelFlag() {
		return comTelFlag;
	}
	public void setComTelFlag(String comTelFlag) {
		this.comTelFlag = comTelFlag;
	}
	public String getComTelO() {
		return comTelO;
	}
	public void setComTelO(String comTelO) {
		this.comTelO = comTelO;
	}
	public String getCellFlag() {
		return cellFlag;
	}
	public void setCellFlag(String cellFlag) {
		this.cellFlag = cellFlag;
	}
	public String getCellO() {
		return cellO;
	}
	public void setCellO(String cellO) {
		this.cellO = cellO;
	}
	public String getHomeTelFlag() {
		return homeTelFlag;
	}
	public void setHomeTelFlag(String homeTelFlag) {
		this.homeTelFlag = homeTelFlag;
	}
	public String getHomeTelO() {
		return homeTelO;
	}
	public void setHomeTelO(String homeTelO) {
		this.homeTelO = homeTelO;
	}
	public String getDayTelFlag() {
		return dayTelFlag;
	}
	public void setDayTelFlag(String dayTelFlag) {
		this.dayTelFlag = dayTelFlag;
	}
	public String getDayTelO() {
		return dayTelO;
	}
	public void setDayTelO(String dayTelO) {
		this.dayTelO = dayTelO;
	}
	public String getNightTelFlag() {
		return nightTelFlag;
	}
	public void setNightTelFlag(String nightTelFlag) {
		this.nightTelFlag = nightTelFlag;
	}
	public String getNightTelO() {
		return nightTelO;
	}
	public void setNightTelO(String nightTelO) {
		this.nightTelO = nightTelO;
	}
	public String getHomeAddZip() {
		return homeAddZip;
	}
	public void setHomeAddZip(String homeAddZip) {
		this.homeAddZip = homeAddZip;
	}
	public String getMailAddZip() {
		return mailAddZip;
	}
	public void setMailAddZip(String mailAddZip) {
		this.mailAddZip = mailAddZip;
	}
	public String getLiveAddZip() {
		return liveAddZip;
	}
	public void setLiveAddZip(String liveAddZip) {
		this.liveAddZip = liveAddZip;
	}
	public String getHomeEtc() {
		return homeEtc;
	}
	public void setHomeEtc(String homeEtc) {
		this.homeEtc = homeEtc;
	}
	public String getMailEtc() {
		return mailEtc;
	}
	public void setMailEtc(String mailEtc) {
		this.mailEtc = mailEtc;
	}
	public String getLiveEtc() {
		return liveEtc;
	}
	public void setLiveEtc(String liveEtc) {
		this.liveEtc = liveEtc;
	}
	public String getmPath() {
		return mPath;
	}
	public void setmPath(String mPath) {
		this.mPath = mPath;
	}
	public String getbS929RES() {
		return bS929RES;
	}
	public void setbS929RES(String bS929RES) {
		this.bS929RES = bS929RES;
	}
	public String getCId() {
		return cId;
	}
	public void setCId(String cId) {
		this.cId = cId;
	}
	
	public String getIdType() {
		return idType;
	}
	public void setIdType(String idType) {
		this.idType = idType;
	}
	
	public String getBRFlag() {
		return bRFlag;
	}
	public void setBRFlag(String bRFlag) {
		this.bRFlag = bRFlag;
	}
	
	public String getBRRFlag() {
		return bRRFlag;
	}
	public void setBRRFlag(String bRRFlag) {
		this.bRRFlag = bRRFlag;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getNCRFlag() {
		return nCRFlag;
	}
	public void setNCRFlag(String nCRFlag) {
		this.nCRFlag = nCRFlag;
	}
	
	public String getNCRLink() {
		return nCRLink;
	}
	public void setNCRLink(String nCRLink) {
		this.nCRLink = nCRLink;
	}
	
	public String getNC993() {
		return nC993;
	}
	public void setNC993(String nC993) {
		this.nC993 = nC993;
	}
	
	public String getNC993Data() {
		return nC993Data;
	}
	public void setNC993Data(String nC993Data) {
		this.nC993Data = nC993Data;
	}
	
	public String getEName() {
		return eName;
	}
	public void setEName(String eName) {
		this.eName = eName;
	}
	
	public String getENCRFlag() {
		return eNCRFlag;
	}
	public void setENCRFlag(String eNCRFlag) {
		this.eNCRFlag = eNCRFlag;
	}
	
	public String getENCRLink() {
		return eNCRLink;
	}
	public void setENCRLink(String eNCRLink) {
		this.eNCRLink = eNCRLink;
	}
	
	public String getENC993() {
		return eNC993;
	}
	public void setENC993(String eNC993) {
		this.eNC993 = eNC993;
	}
	
	public String getENC993Data() {
		return eNC993Data;
	}
	public void setENC993Data(String eNC993Data) {
		this.eNC993Data = eNC993Data;
	}
	
	public String getIdDFlag() {
		return idDFlag;
	}
	public void setIdDFlag(String idDFlag) {
		this.idDFlag = idDFlag;
	}
	
	public String getIdDO() {
		return idDO;
	}
	public void setIdDO(String idDO) {
		this.idDO = idDO;
	}
	
	public String getIdDLink() {
		return idDLink;
	}
	public void setIdDLink(String idDLink) {
		this.idDLink = idDLink;
	}
	
	public String getComT() {
		return comT;
	}
	public void setComT(String comT) {
		this.comT = comT;
	}
	
	public String getComTO() {
		return comTO;
	}
	public void setComTO(String comTO) {
		this.comTO = comTO;
	}
	
	public String getNation() {
		return nation;
	}
	public void setNation(String nation) {
		this.nation = nation;
	}
	
	public String getNationO() {
		return nationO;
	}
	public void setNationO(String nationO) {
		this.nationO = nationO;
	}
	
	public String getBirthP() {
		return birthP;
	}
	public void setBirthP(String birthP) {
		this.birthP = birthP;
	}
	
	public String getBirthPO() {
		return birthPO;
	}
	public void setBirthPO(String birthPO) {
		this.birthPO = birthPO;
	}
	
	public String getBirthD() {
		return birthD;
	}
	public void setBirthD(String birthD) {
		this.birthD = birthD;
	}
	
	public String getMarrFlag() {
		return marrFlag;
	}
	public void setMarrFlag(String marrFlag) {
		this.marrFlag = marrFlag;
	}
	
	public String getMarrO() {
		return marrO;
	}
	public void setMarrO(String marrO) {
		this.marrO = marrO;
	}
	
	public String getEduFlag() {
		return eduFlag;
	}
	public void setEduFlag(String eduFlag) {
		this.eduFlag = eduFlag;
	}
	
	public String getEduO() {
		return eduO;
	}
	public void setEduO(String eduO) {
		this.eduO = eduO;
	}
	
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	
	public String getJobO() {
		return jobO;
	}
	public void setJobO(String jobO) {
		this.jobO = jobO;
	}
	public String getJobCom() {
		return jobCom;
	}
	public void setJobCom(String jobCom) {
		this.jobCom = jobCom;
	}
	public String getSarUni() {
		return sarUni;
	}
	public void setSarUni(String sarUni) {
		this.sarUni = sarUni;
	}
	public String getPosFlag() {
		return posFlag;
	}
	public void setPosFlag(String posFlag) {
		this.posFlag = posFlag;
	}
	public String getPosName() {
		return posName;
	}
	public void setPosName(String posName) {
		this.posName = posName;
	}
	public String getBConFlag() {
		return bConFlag;
	}
	public void setBConFlag(String bConFlag) {
		this.bConFlag = bConFlag;
	}
	public String getSY() {
		return sY;
	}
	public void setSY(String sY) {
		this.sY = sY;
	}
	public String getIPY() {
		return iPY;
	}
	public void setIPY(String iPY) {
		this.iPY = iPY;
	}
	public String getRPY() {
		return rPY;
	}
	public void setRPY(String rPY) {
		this.rPY = rPY;
	}
	public String getBill() {
		return bill;
	}
	public void setBill(String bill) {
		this.bill = bill;
	}
	
	
	public String getHomeAddFlag() {
		return homeAddFlag;
	}
	public void setHomeAddFlag(String homeAddFlag) {
		this.homeAddFlag = homeAddFlag;
	}
	public String getHomeO() {
		return homeO;
	}
	public void setHomeO(String homeO) {
		this.homeO = homeO;
	}
	public String getHomeAdd() {
		return homeAdd;
	}
	public void setHomeAdd(String homeAdd) {
		this.homeAdd = homeAdd;
	}
	public String getHomeZip() {
		return homeZip;
	}
	public void setHomeZip(String homeZip) {
		this.homeZip = homeZip;
	}
	public String getHomeCity() {
		return homeCity;
	}
	public void setHomeCity(String homeCity) {
		this.homeCity = homeCity;
	}
	public String getHomeArea() {
		return homeArea;
	}
	public void setHomeArea(String homeArea) {
		this.homeArea = homeArea;
	}
	public String getHomeStreet() {
		return homeStreet;
	}
	public void setHomeStreet(String homeStreet) {
		this.homeStreet = homeStreet;
	}
	public String getHomeLane() {
		return homeLane;
	}
	public void setHomeLane(String homeLane) {
		this.homeLane = homeLane;
	}
	public String getHomeAly() {
		return homeAly;
	}
	public void setHomeAly(String homeAly) {
		this.homeAly = homeAly;
	}
	public String getHomeNum() {
		return homeNum;
	}
	public void setHomeNum(String homeNum) {
		this.homeNum = homeNum;
	}
	public String getHomeOf() {
		return homeOf;
	}
	public void setHomeOf(String homeOf) {
		this.homeOf = homeOf;
	}
	public String getHomeFlr() {
		return homeFlr;
	}
	public void setHomeFlr(String homeFlr) {
		this.homeFlr = homeFlr;
	}
	public String getMailAddFlag() {
		return mailAddFlag;
	}
	public void setMailAddFlag(String mailAddFlag) {
		this.mailAddFlag = mailAddFlag;
	}
	public String getMailO() {
		return mailO;
	}
	public void setMailO(String mailO) {
		this.mailO = mailO;
	}
	public String getMailAdd() {
		return mailAdd;
	}
	public void setMailAdd(String mailAdd) {
		this.mailAdd = mailAdd;
	}
	public String getMailZip() {
		return mailZip;
	}
	public void setMailZip(String mailZip) {
		this.mailZip = mailZip;
	}
	public String getMailCity() {
		return mailCity;
	}
	public void setMailCity(String mailCity) {
		this.mailCity = mailCity;
	}
	public String getMailArea() {
		return mailArea;
	}
	public void setMailArea(String mailArea) {
		this.mailArea = mailArea;
	}
	public String getMailStreet() {
		return mailStreet;
	}
	public void setMailStreet(String mailStreet) {
		this.mailStreet = mailStreet;
	}
	public String getMailLane() {
		return mailLane;
	}
	public void setMailLane(String mailLane) {
		this.mailLane = mailLane;
	}
	public String getMailAly() {
		return mailAly;
	}
	public void setMailAly(String mailAly) {
		this.mailAly = mailAly;
	}
	public String getMailNum() {
		return mailNum;
	}
	public void setMailNum(String mailNum) {
		this.mailNum = mailNum;
	}
	public String getMailOf() {
		return mailOf;
	}
	public void setMailOf(String mailOf) {
		this.mailOf = mailOf;
	}
	public String getMailFlr() {
		return mailFlr;
	}
	public void setMailFlr(String mailFlr) {
		this.mailFlr = mailFlr;
	}
	public String getLiveAddFlag() {
		return liveAddFlag;
	}
	public void setLiveAddFlag(String liveAddFlag) {
		this.liveAddFlag = liveAddFlag;
	}
	public String getLiveO() {
		return liveO;
	}
	public void setLiveO(String liveO) {
		this.liveO = liveO;
	}
	public String getLiveAdd() {
		return liveAdd;
	}
	public void setLiveAdd(String liveAdd) {
		this.liveAdd = liveAdd;
	}
	public String getLiveZip() {
		return liveZip;
	}
	public void setLiveZip(String liveZip) {
		this.liveZip = liveZip;
	}
	public String getLiveCity() {
		return liveCity;
	}
	public void setLiveCity(String liveCity) {
		this.liveCity = liveCity;
	}
	public String getLiveArea() {
		return liveArea;
	}
	public void setLiveArea(String liveArea) {
		this.liveArea = liveArea;
	}
	public String getLiveStreet() {
		return liveStreet;
	}
	public void setLiveStreet(String liveStreet) {
		this.liveStreet = liveStreet;
	}
	public String getLiveLane() {
		return liveLane;
	}
	public void setLiveLane(String liveLane) {
		this.liveLane = liveLane;
	}
	public String getLiveAly() {
		return liveAly;
	}
	public void setLiveAly(String liveAly) {
		this.liveAly = liveAly;
	}
	public String getLiveNum() {
		return liveNum;
	}
	public void setLiveNum(String liveNum) {
		this.liveNum = liveNum;
	}
	public String getLiveOf() {
		return liveOf;
	}
	public void setLiveOf(String liveOf) {
		this.liveOf = liveOf;
	}
	public String getLiveFlr() {
		return liveFlr;
	}
	public void setLiveFlr(String liveFlr) {
		this.liveFlr = liveFlr;
	}
	public String getComTelH() {
		return comTelH;
	}
	public void setComTelH(String comTelH) {
		this.comTelH = comTelH;
	}
	public String getComTel() {
		return comTel;
	}
	public void setComTel(String comTel) {
		this.comTel = comTel;
	}
	public String getComTelExt() {
		return comTelExt;
	}
	public void setComTelExt(String comTelExt) {
		this.comTelExt = comTelExt;
	}
	
	public String getCell() {
		return cell;
	}
	public void setCell(String cell) {
		this.cell = cell;
	}
	
	public String getDayTelH() {
		return dayTelH;
	}
	public void setDayTelH(String dayTelH) {
		this.dayTelH = dayTelH;
	}
	
	public String getDayTel() {
		return dayTel;
	}
	public void setDayTel(String dayTel) {
		this.dayTel = dayTel;
	}
	
	public String getDayTelExt() {
		return dayTelExt;
	}
	public void setDayTelExt(String dayTelExt) {
		this.dayTelExt = dayTelExt;
	}
	
	public String getNightTelH() {
		return nightTelH;
	}
	public void setNightTelH(String nightTelH) {
		this.nightTelH = nightTelH;
	}
	
	public String getNightTel() {
		return nightTel;
	}
	public void setNightTel(String nightTel) {
		this.nightTel = nightTel;
	}
	
	
	public String getNightTelExt() {
		return nightTelExt;
	}
	public void setNightTelExt(String nightTelExt) {
		this.nightTelExt = nightTelExt;
	}
	
	public String getHomeTelH() {
		return homeTelH;
	}
	public void setHomeTelH(String homeTelH) {
		this.homeTelH = homeTelH;
	}
	
	public String getHomeTel() {
		return homeTel;
	}
	public void setHomeTel(String homeTel) {
		this.homeTel = homeTel;
	}
	
	public String getFaxH() {
		return faxH;
	}
	public void setFaxH(String faxH) {
		this.faxH = faxH;
	}
	
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getFATCA() {
		return fatca;
	}
	public void setFATCA(String fatca) {
		this.fatca = fatca;
	}
	
	public String getIAMFlag() {
		return iAMFlag;
	}
	public void setIAMFlag(String iAMFlag) {
		this.iAMFlag = iAMFlag;
	}
	
	public String getIAMO() {
		return iAMO;
	}
	public void setIAMO(String iAMO) {
		this.iAMO = iAMO;
	}
	
	public String getBRPFlag() {
		return bRPFlag;
	}
	public void setBRPFlag(String bRPFlag) {
		this.bRPFlag = bRPFlag;
	}
	
	public String getBRPO() {
		return bRPO;
	}
	public void setBRPO(String bRPO) {
		this.bRPO = bRPO;
	}
	public String getInAmount() {
		return inAmount;
	}
	public void setInAmount(String inAmount) {
		this.inAmount = inAmount;
	}
	public String getInTimes() {
		return inTimes;
	}
	public void setInTimes(String inTimes) {
		this.inTimes = inTimes;
	}
	public String getOutAmount() {
		return outAmount;
	}
	public void setOutAmount(String outAmount) {
		this.outAmount = outAmount;
	}
	public String getOutTimes() {
		return outTimes;
	}
	public void setOutTimes(String outTimes) {
		this.outTimes = outTimes;
	}
	
	public String getBSFlag() {
		return bSFlag;
	}
	public void setBSFlag(String bSFlag) {
		this.bSFlag = bSFlag;
	}
	
	public String getLTD() {
		return lTD;
	}
	public void setLTD(String lTD) {
		this.lTD = lTD;
	}
	
	public String getComBS() {
		return comBS;
	}
	public void setComBS(String comBS) {
		this.comBS = comBS;
	}
	
	public String getComBSP() {
		return comBSP;
	}
	public void setComBSP(String comBSP) {
		this.comBSP = comBSP;
	}
	
	public String getComBSA() {
		return comBSA;
	}
	public void setComBSA(String comBSA) {
		this.comBSA = comBSA;
	}
	
	public String getShBS() {
		return shBS;
	}
	public void setShBS(String shBS) {
		this.shBS = shBS;
	}
	
	public String getShBSP() {
		return shBSP;
	}
	public void setShBSP(String shBSP) {
		this.shBSP = shBSP;
	}
	
	public String getShBSA() {
		return shBSA;
	}
	public void setShBSA(String shBSA) {
		this.shBSA = shBSA;
	}
	
	public String getSpecFlag() {
		return specFlag;
	}
	public void setSpecFlag(String specFlag) {
		this.specFlag = specFlag;
	}
	public String getStockC() {
		return stockC;
	}
	public void setStockC(String stockC) {
		this.stockC = stockC;
	}
	public String getStockEx() {
		return stockEx;
	}
	public void setStockEx(String stockEx) {
		this.stockEx = stockEx;
	}
	public String getStockCom() {
		return stockCom;
	}
	public void setStockCom(String stockCom) {
		this.stockCom = stockCom;
	}
	public String getbTypeChk() {
		return bTypeChk;
	}
	public void setbTypeChk(String bTypeChk) {
		this.bTypeChk = bTypeChk;
	}
	public String getComM() {
		return comM;
	}
	public void setComM(String comM) {
		this.comM = comM;
	}
	public String getSpt() {
		return spt;
	}
	public void setSpt(String spt) {
		this.spt = spt;
	}
	public String getTof() {
		return tof;
	}
	public void setTof(String tof) {
		this.tof = tof;
	}
	public String getOp() {
		return op;
	}
	public void setOp(String op) {
		this.op = op;
	}
	public String getAbnFlag() {
		return abnFlag;
	}
	public void setAbnFlag(String abnFlag) {
		this.abnFlag = abnFlag;
	}
	public String getUId() {
		return uId;
	}
	public void setUId(String uId) {
		this.uId = uId;
	}
	public String getUOpnion() {
		return uOpnion;
	}
	public void setUOpnion(String uOpnion) {
		this.uOpnion = uOpnion;
	}
	public String getURemark() {
		return uRemark;
	}
	public void setURemark(String uRemark) {
		this.uRemark = uRemark;
	}
	public String getSId() {
		return sId;
	}
	public void setSId(String sId) {
		this.sId = sId;
	}
	public String getSRemark() {
		return sRemark;
	}
	public void setSRemark(String sRemark) {
		this.sRemark = sRemark;
	}
	public String getcDateTime() {
		return cDateTime;
	}
	public void setcDateTime(String cDateTime) {
		this.cDateTime = cDateTime;
	}
	public String getEditTime() {
		return editTime;
	}
	public void setEditTime(String editTime) {
		this.editTime = editTime;
	}
	public String getOpenTime() {
		return openTime;
	}
	public void setOpenTime(String openTime) {
		this.openTime = openTime;
	}
	public String getCrs() {
		return crs;
	}
	public void setCrs(String crs) {
		this.crs = crs;
	}
	public String getObu() {
		return obu;
	}
	public void setObu(String obu) {
		this.obu = obu;
	}
	public String getFour() {
		return four;
	}
	public void setFour(String four) {
		this.four = four;
	}
	public String getpPNum() {
		return pPNum;
	}
	public void setpPNum(String pPNum) {
		this.pPNum = pPNum;
	}
	public String getpPDay() {
		return pPDay;
	}
	public void setpPDay(String pPDay) {
		this.pPDay = pPDay;
	}
	public String getMId() {
		return mId;
	}
	public void setMId(String mId) {
		this.mId = mId;
	}
	public String getMRemark() {
		return mRemark;
	}
	public void setMRemark(String mRemark) {
		this.mRemark = mRemark;
	}
	public String getRARTime() {
		return rARTime;
	}
	public void setRARTime(String rARTime) {
		this.rARTime = rARTime;
	}
	public String getRARank() {
		return rARank;
	}
	public void setRARank(String rARank) {
		this.rARank = rARank;
	}
	public String getRAScore() {
		return rAScore;
	}
	public void setRAScore(String rAScore) {
		this.rAScore = rAScore;
	}
	public String getRANTime() {
		return rANTime;
	}
	public void setRANTime(String rANTime) {
		this.rANTime = rANTime;
	}
	public String getJobEx() {
		return jobEx;
	}
	public void setJobEx(String jobEx) {
		this.jobEx = jobEx;
	}
	public String getHomeVil() {
		return homeVil;
	}
	public void setHomeVil(String homeVil) {
		this.homeVil = homeVil;
	}
	public String getPosO() {
		return posO;
	}
	public void setPosO(String posO) {
		this.posO = posO;
	}
	public String getcAmount() {
		return cAmount;
	}
	public void setcAmount(String cAmount) {
		this.cAmount = cAmount;
	}
}
