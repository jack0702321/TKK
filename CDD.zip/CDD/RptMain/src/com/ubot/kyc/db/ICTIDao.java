package com.ubot.kyc.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class ICTIDao {
	public ICTIVo findById(String cId, Connection con) {
		String sql = "SELECT CID, UID, BRANCH, RDATETIME FROM [ICTI] WHERE CID = ?";
		ICTIVo vo = new ICTIVo();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				vo.setcId(rs.getString("CID"));
				vo.setuId(rs.getString("UID"));
				vo.setBranch(rs.getString("BRANCH"));
				vo.setrDateTime(rs.getString("RDATETIME"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return vo;	
	}
	
	
	public Map<String, String> getList(String custNo, String sMonth, String dMonth, Connection con) {
		String sql = "SELECT CID,CASE UID WHEN '1049999' THEN '客服' WHEN '1049998' THEN '個網' WHEN '1049997' THEN '數存' WHEN '1049996' THEN 'APP' ELSE UID END UID,RDATETIME FROM [ICTI] WHERE CID=? AND RDATETIME < '" + dMonth + "' AND RDATETIME >= '" + sMonth + "' AND SENDDATA like '%K0000%' ORDER BY UID,RDATETIME";
		Map<String, String> map = new HashMap<String, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			pstmt.setString(1, custNo);
			while (rs.next()) {
				map.put(rs.getString("CID"), rs.getString("UID") + "|" + rs.getString("RDATETIME"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return map;
	}
	
	public boolean existICTI(String cId, Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM [ICTI] WHERE CID = ? AND SENDDATA like '%K0000%'";
		PreparedStatement pstmt = null;
		ResultSet rs = null;		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;		
	}
}
