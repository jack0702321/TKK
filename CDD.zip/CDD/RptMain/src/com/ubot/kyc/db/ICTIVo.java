package com.ubot.kyc.db;

public class ICTIVo {
	private String cId;
	private String uId; 
	private String branch;
	private String rDateTime;
	public String getcId() {
		return cId;
	}
	public void setcId(String cId) {
		this.cId = cId;
	}
	public String getuId() {
		return uId;
	}
	public void setuId(String uId) {
		this.uId = uId;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getrDateTime() {
		return rDateTime;
	}
	public void setrDateTime(String rDateTime) {
		this.rDateTime = rDateTime;
	}
}
