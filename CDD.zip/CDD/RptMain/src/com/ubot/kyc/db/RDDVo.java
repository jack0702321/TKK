package com.ubot.kyc.db;

import java.lang.reflect.Field;

public class RDDVo {

	public RDDVo() {
		// TODO Auto-generated constructor stub
	}
	
	private String cId;
	private String name;
	private String raRank;
	private String raRTime;
	private String RDDWay;
	private String aWay;
	private String aWay2Add;
	private String bWayTel;
	private String bWayDate1;
	private String bWayTime1;
	private String bWayDate2;
	private String bWayTime2;
	private String bWayDate3;
	private String bWayTime3;
	private String cWayDate;
	private String cWayPlace;
	private String RDDWayO;
	private String RDDCoop;
	private String RDDCoopO;
	private String RDDSAR;
	private String RDDTxBP;
	private String RDDTxBPD;
	private String RDDTxPo;
	private String RDDTxPoN;
	private String RDDTxPoY;
	private String RDDTxPoYO;
	private String RDDTxBg;
	private String RDDTxBgBD;
	private String RDDBr12;
	private String RDDOp;
	private String RDDTxMode;
	private String RDDTXModeND;
	private String RDDTxPop;
	private String RDDTxPopND;
	private String RDDIAMFlag;
	private String RDDIAMFlagAList;
	private String RDDIAMFlagAO;
	private String RDDIAMFlagBList;
	private String RDDIAMFlagBO;
	private String RDDIAMFlagCList;
	private String RDDIAMFlagCO;
	private String RDDIAMFlagDList;
	private String RDDIAMFlagDO;
	private String RDDIAMFlagEList;
	private String RDDIAMFlagEO;
	private String RDDIAMFlagFList;
	private String RDDIAMFlagGList;
	private String RDDIAMFlagGO;
	private String RDDIAMFlagHO;
	private String RDDFileP;
	private String RDDVerify;
	private String RDDVerifyO;
	private String RDDVerifyT;
	private String RDDVerifyTAT;
	private String RDDVerifyTBT;
	private String RDDVerifyTCT;
	private String RDDAbnormal;
	private String RDDAbnormalR;
	private String RDDOpinion;
	private String remark;
	private String uId;
	private String sId;
	private String mId;
	private String uTime;
	private String sTime;
	private String mTime;
	private String sRemark;
	private String mRemark;
	private String RDDExist;
	private String RDDExistBDes;
	private String RDDExistCDes;
	private String RDDWayESrc;
	private String RDDTxOpp;
	private String RDDTxOppY;
	private String RDDOBUNation;
	private String RDDOBUH;
	private String RDDTxOppYcDes;
	private String RDDTxOppCDes;
	
	
	public String getsRemark() {
		return sRemark;
	}
	public void setsRemark(String sRemark) {
		this.sRemark = sRemark;
	}
	public String getmRemark() {
		return mRemark;
	}
	public void setmRemark(String mRemark) {
		this.mRemark = mRemark;
	}

	public String getcId() {
		return cId;
	}
	public void setcId(String cId) {
		this.cId = cId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRaRank() {
		return raRank;
	}
	public void setRaRank(String raRank) {
		this.raRank = raRank;
	}
	public String getRaRTime() {
		return raRTime;
	}
	public void setRaRTime(String raRTime) {
		this.raRTime = raRTime;
	}
	public String getRDDWay() {
		return RDDWay;
	}
	public void setRDDWay(String rDDWay) {
		RDDWay = rDDWay;
	}
	public String getaWay() {
		return aWay;
	}
	public void setaWay(String aWay) {
		this.aWay = aWay;
	}
	public String getaWay2Add() {
		return aWay2Add;
	}
	public void setaWay2Add(String aWay2Add) {
		this.aWay2Add = aWay2Add;
	}
	public String getbWayTel() {
		return bWayTel;
	}
	public void setbWayTel(String bWayTel) {
		this.bWayTel = bWayTel;
	}
	public String getbWayDate1() {
		return bWayDate1;
	}
	public void setbWayDate1(String bWayDate1) {
		this.bWayDate1 = bWayDate1;
	}
	public String getbWayTime1() {
		return bWayTime1;
	}
	public void setbWayTime1(String bWayTime1) {
		this.bWayTime1 = bWayTime1;
	}
	public String getbWayDate2() {
		return bWayDate2;
	}
	public void setbWayDate2(String bWayDate2) {
		this.bWayDate2 = bWayDate2;
	}
	public String getbWayTime2() {
		return bWayTime2;
	}
	public void setbWayTime2(String bWayTime2) {
		this.bWayTime2 = bWayTime2;
	}
	public String getbWayDate3() {
		return bWayDate3;
	}
	public void setbWayDate3(String bWayDate3) {
		this.bWayDate3 = bWayDate3;
	}
	public String getbWayTime3() {
		return bWayTime3;
	}
	public void setbWayTime3(String bWayTime3) {
		this.bWayTime3 = bWayTime3;
	}
	public String getcWayDate() {
		return cWayDate;
	}
	public void setcWayDate(String cWayDate) {
		this.cWayDate = cWayDate;
	}
	public String getcWayPlace() {
		return cWayPlace;
	}
	public void setcWayPlace(String cWayPlace) {
		this.cWayPlace = cWayPlace;
	}
	public String getRDDWayO() {
		return RDDWayO;
	}
	public void setRDDWayO(String rDDWayO) {
		RDDWayO = rDDWayO;
	}
	public String getRDDCoop() {
		return RDDCoop;
	}
	public void setRDDCoop(String rDDCoop) {
		RDDCoop = rDDCoop;
	}
	public String getRDDCoopO() {
		return RDDCoopO;
	}
	public void setRDDCoopO(String rDDCoopO) {
		RDDCoopO = rDDCoopO;
	}
	public String getRDDSAR() {
		return RDDSAR;
	}
	public void setRDDSAR(String rDDSAR) {
		RDDSAR = rDDSAR;
	}
	public String getRDDTxBP() {
		return RDDTxBP;
	}
	public void setRDDTxBP(String rDDTxBP) {
		RDDTxBP = rDDTxBP;
	}
	public String getRDDTxBPD() {
		return RDDTxBPD;
	}
	public void setRDDTxBPD(String rDDTxBPD) {
		RDDTxBPD = rDDTxBPD;
	}
	public String getRDDTxPo() {
		return RDDTxPo;
	}
	public void setRDDTxPo(String rDDTxPo) {
		RDDTxPo = rDDTxPo;
	}
	public String getRDDTxPoN() {
		return RDDTxPoN;
	}
	public void setRDDTxPoN(String rDDTxPoN) {
		RDDTxPoN = rDDTxPoN;
	}
	public String getRDDTxPoY() {
		return RDDTxPoY;
	}
	public void setRDDTxPoY(String rDDTxPoY) {
		RDDTxPoY = rDDTxPoY;
	}
	public String getRDDTxPoYO() {
		return RDDTxPoYO;
	}
	public void setRDDTxPoYO(String rDDTxPoYO) {
		RDDTxPoYO = rDDTxPoYO;
	}
	public String getRDDTxBg() {
		return RDDTxBg;
	}
	public void setRDDTxBg(String rDDTxBg) {
		RDDTxBg = rDDTxBg;
	}
	public String getRDDTxBgBD() {
		return RDDTxBgBD;
	}
	public void setRDDTxBgBD(String rDDTxBgBD) {
		RDDTxBgBD = rDDTxBgBD;
	}
	public String getRDDBr12() {
		return RDDBr12;
	}
	public void setRDDBr12(String rDDBr12) {
		RDDBr12 = rDDBr12;
	}
	public String getRDDOp() {
		return RDDOp;
	}
	public void setRDDOp(String rDDOp) {
		RDDOp = rDDOp;
	}
	public String getRDDTxMode() {
		return RDDTxMode;
	}
	public void setRDDTxMode(String rDDTxMode) {
		RDDTxMode = rDDTxMode;
	}
	public String getRDDTXModeND() {
		return RDDTXModeND;
	}
	public void setRDDTXModeND(String rDDTXModeND) {
		RDDTXModeND = rDDTXModeND;
	}
	public String getRDDTxPop() {
		return RDDTxPop;
	}
	public void setRDDTxPop(String rDDTxPop) {
		RDDTxPop = rDDTxPop;
	}
	public String getRDDTxPopND() {
		return RDDTxPopND;
	}
	public void setRDDTxPopND(String rDDTxPopND) {
		RDDTxPopND = rDDTxPopND;
	}
	public String getRDDIAMFlag() {
		return RDDIAMFlag;
	}
	public void setRDDIAMFlag(String rDDIAMFlag) {
		RDDIAMFlag = rDDIAMFlag;
	}
	public String getRDDIAMFlagAList() {
		return RDDIAMFlagAList;
	}
	public void setRDDIAMFlagAList(String rDDIAMFlagAList) {
		RDDIAMFlagAList = rDDIAMFlagAList;
	}
	public String getRDDIAMFlagAO() {
		return RDDIAMFlagAO;
	}
	public void setRDDIAMFlagAO(String rDDIAMFlagAO) {
		RDDIAMFlagAO = rDDIAMFlagAO;
	}
	public String getRDDIAMFlagBList() {
		return RDDIAMFlagBList;
	}
	public void setRDDIAMFlagBList(String rDDIAMFlagBList) {
		RDDIAMFlagBList = rDDIAMFlagBList;
	}
	public String getRDDIAMFlagBO() {
		return RDDIAMFlagBO;
	}
	public void setRDDIAMFlagBO(String rDDIAMFlagBO) {
		RDDIAMFlagBO = rDDIAMFlagBO;
	}
	public String getRDDIAMFlagCList() {
		return RDDIAMFlagCList;
	}
	public void setRDDIAMFlagCList(String rDDIAMFlagCList) {
		RDDIAMFlagCList = rDDIAMFlagCList;
	}
	public String getRDDIAMFlagCO() {
		return RDDIAMFlagCO;
	}
	public void setRDDIAMFlagCO(String rDDIAMFlagCO) {
		RDDIAMFlagCO = rDDIAMFlagCO;
	}
	public String getRDDIAMFlagDList() {
		return RDDIAMFlagDList;
	}
	public void setRDDIAMFlagDList(String rDDIAMFlagDList) {
		RDDIAMFlagDList = rDDIAMFlagDList;
	}
	public String getRDDIAMFlagDO() {
		return RDDIAMFlagDO;
	}
	public void setRDDIAMFlagDO(String rDDIAMFlagDO) {
		RDDIAMFlagDO = rDDIAMFlagDO;
	}
	public String getRDDIAMFlagEList() {
		return RDDIAMFlagEList;
	}
	public void setRDDIAMFlagEList(String rDDIAMFlagEList) {
		RDDIAMFlagEList = rDDIAMFlagEList;
	}
	public String getRDDIAMFlagEO() {
		return RDDIAMFlagEO;
	}
	public void setRDDIAMFlagEO(String rDDIAMFlagEO) {
		RDDIAMFlagEO = rDDIAMFlagEO;
	}
	public String getRDDIAMFlagFList() {
		return RDDIAMFlagFList;
	}
	public void setRDDIAMFlagFList(String rDDIAMFlagFList) {
		RDDIAMFlagFList = rDDIAMFlagFList;
	}
	public String getRDDIAMFlagGList() {
		return RDDIAMFlagGList;
	}
	public void setRDDIAMFlagGList(String rDDIAMFlagGList) {
		RDDIAMFlagGList = rDDIAMFlagGList;
	}
	public String getRDDIAMFlagGO() {
		return RDDIAMFlagGO;
	}
	public void setRDDIAMFlagGO(String rDDIAMFlagGO) {
		RDDIAMFlagGO = rDDIAMFlagGO;
	}
	public String getRDDIAMFlagHO() {
		return RDDIAMFlagHO;
	}
	public void setRDDIAMFlagHO(String rDDIAMFlagHO) {
		RDDIAMFlagHO = rDDIAMFlagHO;
	}
	public String getRDDFileP() {
		return RDDFileP;
	}
	public void setRDDFileP(String rDDFileP) {
		RDDFileP = rDDFileP;
	}
	public String getRDDVerify() {
		return RDDVerify;
	}
	public void setRDDVerify(String rDDVerify) {
		RDDVerify = rDDVerify;
	}
	public String getRDDVerifyO() {
		return RDDVerifyO;
	}
	public void setRDDVerifyO(String rDDVerifyO) {
		RDDVerifyO = rDDVerifyO;
	}
	public String getRDDVerifyT() {
		return RDDVerifyT;
	}
	public void setRDDVerifyT(String rDDVerifyT) {
		RDDVerifyT = rDDVerifyT;
	}
	public String getRDDVerifyTAT() {
		return RDDVerifyTAT;
	}
	public void setRDDVerifyTAT(String rDDVerifyTAT) {
		RDDVerifyTAT = rDDVerifyTAT;
	}
	public String getRDDVerifyTBT() {
		return RDDVerifyTBT;
	}
	public void setRDDVerifyTBT(String rDDVerifyTBT) {
		RDDVerifyTBT = rDDVerifyTBT;
	}
	public String getRDDVerifyTCT() {
		return RDDVerifyTCT;
	}
	public void setRDDVerifyTCT(String rDDVerifyTCT) {
		RDDVerifyTCT = rDDVerifyTCT;
	}
	public String getRDDAbnormal() {
		return RDDAbnormal;
	}
	public void setRDDAbnormal(String rDDAbnormal) {
		RDDAbnormal = rDDAbnormal;
	}
	public String getRDDAbnormalR() {
		return RDDAbnormalR;
	}
	public void setRDDAbnormalR(String rDDAbnormalR) {
		RDDAbnormalR = rDDAbnormalR;
	}
	public String getRDDOpinion() {
		return RDDOpinion;
	}
	public void setRDDOpinion(String rDDOpinion) {
		RDDOpinion = rDDOpinion;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getuId() {
		return uId;
	}
	public void setuId(String uId) {
		this.uId = uId;
	}
	public String getsId() {
		return sId;
	}
	public void setsId(String sId) {
		this.sId = sId;
	}
	public String getmId() {
		return mId;
	}
	public void setmId(String mId) {
		this.mId = mId;
	}
	public String getuTime() {
		return uTime;
	}
	public void setuTime(String uTime) {
		this.uTime = uTime;
	}
	public String getsTime() {
		return sTime;
	}
	public void setsTime(String sTime) {
		this.sTime = sTime;
	}
	public String getmTime() {
		return mTime;
	}
	public void setmTime(String mTime) {
		this.mTime = mTime;
	}
	
	
	public String getRDDExist() {
		return RDDExist;
	}
	public void setRDDExist(String rDDExist) {
		RDDExist = rDDExist;
	}
	public String getRDDExistBDes() {
		return RDDExistBDes;
	}
	public void setRDDExistBDes(String rDDExistBDes) {
		RDDExistBDes = rDDExistBDes;
	}
	public String getRDDExistCDes() {
		return RDDExistCDes;
	}
	public void setRDDExistCDes(String rDDExistCDes) {
		RDDExistCDes = rDDExistCDes;
	}
	public String getRDDWayESrc() {
		return RDDWayESrc;
	}
	public void setRDDWayESrc(String rDDWayESrc) {
		RDDWayESrc = rDDWayESrc;
	}
	public String getRDDTxOpp() {
		return RDDTxOpp;
	}
	public void setRDDTxOpp(String rDDTxOpp) {
		RDDTxOpp = rDDTxOpp;
	}
	public String getRDDTxOppY() {
		return RDDTxOppY;
	}
	public void setRDDTxOppY(String rDDTxOppY) {
		RDDTxOppY = rDDTxOppY;
	}
	public String getRDDOBUNation() {
		return RDDOBUNation;
	}
	public void setRDDOBUNation(String rDDOBUNation) {
		RDDOBUNation = rDDOBUNation;
	}
	public String getRDDOBUH() {
		return RDDOBUH;
	}
	public void setRDDOBUH(String rDDOBUH) {
		RDDOBUH = rDDOBUH;
	}
	public String getRDDTxOppYcDes() {
		return RDDTxOppYcDes;
	}
	public void setRDDTxOppYcDes(String rDDTxOppYcDes) {
		RDDTxOppYcDes = rDDTxOppYcDes;
	}
	public String getRDDTxOppCDes() {
		return RDDTxOppCDes;
	}
	public void setRDDTxOppCDes(String rDDTxOppCDes) {
		RDDTxOppCDes = rDDTxOppCDes;
	}
	public void showAll() throws IllegalAccessException {
		
		Field[] fields = this.getClass().getDeclaredFields();
	
	try {	
		for(Field f : fields){
			f.setAccessible(true);
			if(f.getType().isAssignableFrom(String.class)) {
	            System.out.print("Field name: " + f.getName());
	        }
			
		}	 
		
	} catch (IllegalArgumentException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
}
}
