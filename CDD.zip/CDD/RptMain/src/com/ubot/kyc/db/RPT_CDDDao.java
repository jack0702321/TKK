package com.ubot.kyc.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class RPT_CDDDao {
	public boolean insertCDD(String cId, String name, String time, String risk, String branch, Connection con) {
		boolean result = true;
		String sql = "INSERT INTO RPT_CDD (CID,TAG,NAME,TIME,RISK,BRANCH) VALUES (?,?,?,?,?,?)";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			pstmt.setString(2, "0");
			pstmt.setString(3, name);
			pstmt.setString(4, time);
			pstmt.setString(5, risk);
			pstmt.setString(6, branch);
			int cnt = pstmt.executeUpdate();
			result = (cnt > 0) ? true : false;
		} catch (SQLException e) {
			System.out.println("問題ID:" + cId);
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("問題ID:" + cId);
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean insertDaily(Connection con) {
		boolean result = true;
		String sql = "INSERT INTO RPT_DAY (CID, TAG) SELECT CID,CONVERT(varchar(100), GETDATE(), 23) FROM RPT_CDD WHERE TAG = '2'";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			int cnt = pstmt.executeUpdate();
			result = (cnt > 0) ? true : false;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean updateTag1(String cId, Connection con) {
		boolean result = true;
		PreparedStatement pstmt = null;
		String sql = "UPDATE RPT_CDD SET TAG=? WHERE CID = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "1");
			pstmt.setString(2, cId);
			
			int cnt = pstmt.executeUpdate();
			result = (cnt > 0) ? true : false;
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean updateTag2(String cId, Connection con) {
		boolean result = true;
		PreparedStatement pstmt = null;
		String sql = "UPDATE RPT_CDD SET TAG=? WHERE CID = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "2");
			pstmt.setString(2, cId);
			
			int cnt = pstmt.executeUpdate();
			result = (cnt > 0) ? true : false;
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean updateTag3(Connection con) {
		boolean result = true;
		PreparedStatement pstmt = null;
		String sql = "UPDATE RPT_CDD SET TAG='3' WHERE CID IN (SELECT CID FROM CUST WHERE SUBSTRING(EDITTIME,0,11) >= CONVERT(varchar(100), GETDATE()-1, 23))";
		try {
			pstmt = con.prepareStatement(sql);
			
			int cnt = pstmt.executeUpdate();
			result = (cnt > 0) ? true : false;
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean exist(String cId, Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM RPT_CDD WHERE CID = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;		
	}
	
	public boolean existCDD(String cId, String str, Connection con) {
		boolean r = false;
//		String sql = "SELECT TOP 1 1 FROM RPT_CDD WHERE CID = ? AND TAG IN ('0','1','3') AND BRANCH != '911'";
//		String sql = "SELECT TOP 1 1 FROM RPT_CDD WHERE CID = ? AND TAG IN ('0','1','3')";
		String sql = "SELECT TOP 1 1 FROM RPT_CDD WHERE CID = ? AND TAG IN ('0','1','3') AND BRANCH NOT IN " + str;

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;		
	}
	
	public boolean delete(Connection con) {
		boolean result = true;
		String sql = "DELETE FROM RPT_CDD";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			int cnt = pstmt.executeUpdate(); 
			result = (cnt > 0) ? true : false;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean deleteCDDY(Connection con) {
		boolean result = true;
		String sql = "DELETE FROM RPT_CDDY";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			int cnt = pstmt.executeUpdate(); 
			result = (cnt > 0) ? true : false;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean deleteCDDN(Connection con) {
		boolean result = true;
		String sql = "DELETE FROM RPT_CDDN";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			int cnt = pstmt.executeUpdate(); 
			result = (cnt > 0) ? true : false;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean deleteDay(Connection con) {
		boolean result = true;
		String sql = "DELETE FROM RPT_DAY";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			int cnt = pstmt.executeUpdate(); 
			result = (cnt > 0) ? true : false;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean deleteDaily(Connection con) {
		boolean result = true;
		String sql = "DELETE FROM RPT_DAY WHERE CID IN (SELECT CID FROM CUST WHERE SUBSTRING(EDITTIME,0,11) >= CONVERT(varchar(100), GETDATE()-1, 23))";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			int cnt = pstmt.executeUpdate(); 
			result = (cnt > 0) ? true : false;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public RPT_CDDVo findById(String cId, Connection con) {
		String sql = "SELECT CID, TAG, NAME, TIME, RISK, BRANCH FROM RPT_CDD WHERE CID = ?";
		RPT_CDDVo vo = new RPT_CDDVo();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				vo.setcId(rs.getString("CID"));
				vo.setTag(rs.getString("TAG"));
				vo.setName(rs.getString("NAME"));
				vo.setTime(rs.getString("TIME"));
				vo.setRisk(rs.getString("RISK"));
				vo.setBranch(rs.getString("BRANCH"));
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return vo;	
	}
	
	public Map<Integer, String> cDDMap(String str, Connection con) {
//		String sql = "SELECT CID FROM RPT_CDD WHERE TAG IN ('0','1','3') AND BRANCH != '911' ORDER BY CID ASC";
//		String sql = "SELECT CID FROM RPT_CDD WHERE TAG IN ('0','1','3') ORDER BY CID ASC";
//		String sql = "SELECT CID FROM RPT_CDD WHERE TAG IN ('0','1','3') AND BRANCH NOT IN " + str + " ORDER BY CID ASC";
		String sql = "SELECT CID FROM RPT_CDD WHERE TAG IN ('0','1','3') AND BRANCH NOT IN " + str + " ORDER BY SUBSTRING(TIME, 0, 11) ASC, CID ASC";
		
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("CID"));
				cnt++;
			}
		} catch (SQLException sqlE) {			
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<Integer, String> cDDBranch(Connection con) {
		String sql = "SELECT BRANCH FROM RPT_BRA";
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("BRANCH"));
				cnt++;
			}
		} catch (SQLException sqlE) {			
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<String, String> cIdDaily(Connection con) {
		String sql = "SELECT CID FROM RPT_DAY";
		Map<String, String> map = new HashMap<String, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(rs.getString("CID"),"");
			}
		} catch (SQLException sqlE) {			
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<Integer, String> getCDDN(Connection con) {
		String sql = "SELECT BRANCH, COUNT(CID) CUNT FROM RPT_CDD WHERE TAG IN ('0','1','3') AND CID IN (SELECT CID FROM RPT_CDDN) GROUP BY BRANCH ORDER BY BRANCH ASC";
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("BRANCH") + "|" + rs.getString("CUNT") + "\r\n");
				cnt++;
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<Integer, String> getCDDY(Connection con) {
		String sql = "SELECT BRANCH, COUNT(CID) CUNT FROM RPT_CDD WHERE TAG IN ('0','1','3') AND CID IN (SELECT CID FROM RPT_CDDY) GROUP BY BRANCH ORDER BY BRANCH ASC";
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("BRANCH") + "|" + rs.getString("CUNT") + "\r\n");
				cnt++;
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<Integer, String> getCDDN_H(Connection con) {
		String sql = "SELECT BRANCH, COUNT(CID) CUNT FROM RPT_CDD WHERE TAG IN ('0','1','3') AND RISK = 'H' AND CID IN (SELECT CID FROM RPT_CDDN) GROUP BY BRANCH ORDER BY BRANCH ASC";
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("BRANCH") + "|" + rs.getString("CUNT") + "\r\n");
				cnt++;
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<Integer, String> getCDDY_H(Connection con) {
		String sql = "SELECT BRANCH, COUNT(CID) CUNT FROM RPT_CDD WHERE TAG IN ('0','1','3') AND RISK = 'H' AND CID IN (SELECT CID FROM RPT_CDDY) GROUP BY BRANCH ORDER BY BRANCH ASC";
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("BRANCH") + "|" + rs.getString("CUNT") + "\r\n");
				cnt++;
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<Integer, String> getCDDN_M(Connection con) {
		String sql = "SELECT BRANCH, COUNT(CID) CUNT FROM RPT_CDD WHERE TAG IN ('0','1','3') AND RISK = 'M' AND CID IN (SELECT CID FROM RPT_CDDN) GROUP BY BRANCH ORDER BY BRANCH ASC";
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("BRANCH") + "|" + rs.getString("CUNT") + "\r\n");
				cnt++;
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<Integer, String> getCDDY_M(Connection con) {
		String sql = "SELECT BRANCH, COUNT(CID) CUNT FROM RPT_CDD WHERE TAG IN ('0','1','3') AND RISK = 'M' AND CID IN (SELECT CID FROM RPT_CDDY) GROUP BY BRANCH ORDER BY BRANCH ASC";
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("BRANCH") + "|" + rs.getString("CUNT") + "\r\n");
				cnt++;
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<Integer, String> getCDDN_L(Connection con) {
		String sql = "SELECT BRANCH, COUNT(CID) CUNT FROM RPT_CDD WHERE TAG IN ('0','1','3') AND RISK = 'L' AND CID IN (SELECT CID FROM RPT_CDDN) GROUP BY BRANCH ORDER BY BRANCH ASC";
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("BRANCH") + "|" + rs.getString("CUNT") + "\r\n");
				cnt++;
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<Integer, String> getEdit(Connection con) {
		String sql = "SELECT RPT_CDD.CID, EDITTIME FROM RPT_CDD LEFT JOIN CUST ON RPT_CDD.CID = CUST.CID";
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("CID") + "|" + rs.getString("EDITTIME") + "\r\n");
				cnt++;
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<Integer, String> getTag(Connection con) {
		String sql = "SELECT CID, TAG, BRANCH FROM RPT_CDD";
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("CID") + "|" + rs.getString("TAG") + "|" + rs.getString("BRANCH") + "\r\n");
				cnt++;
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
}
