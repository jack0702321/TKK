package com.ubot.kyc.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VirtualAccountDao {
	public boolean insertVAccount(VirtualAccountVo vo, Connection con) throws SQLException {
		boolean result = true;
		String sql = "INSERT INTO VIRTUALACCOUNT (CID, DATADATE) VALUES(?, ?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		pstmt.setString(1, vo.getcId());
		pstmt.setString(2, vo.getDataDate());
		
		int cnt = pstmt.executeUpdate();
		result = (cnt > 0) ? true : false;
		pstmt.close();
		return result;
	}
	
	public boolean existVA(String cId, Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM VIRTUALACCOUNT WHERE CID = ? AND DATADATE = (SELECT MAX(DATADATE) FROM VIRTUALACCOUNT)";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;
	}	
}
