package com.ubot.kyc.db;

public class VirtualAccountVo {
	private String cId;
	private String dataDate;
	
	public VirtualAccountVo() {
		super();
	}
	
	public VirtualAccountVo(String cId, String dataDate) {
		super();
		this.cId = cId;
		this.dataDate = dataDate;
	}

	public String getcId() {
		return cId;
	}
	public void setcId(String cId) {
		this.cId = cId;
	}
	public String getDataDate() {
		return dataDate;
	}
	public void setDataDate(String dataDate) {
		this.dataDate = dataDate;
	}
}