
public class RptMain {
	public static void main(String[] args) {
		WeekReportBig52 wRpt = new WeekReportBig52();
		wRpt.WeekRpt();
	}
}
