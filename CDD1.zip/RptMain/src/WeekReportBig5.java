import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet; // normalizeReportBranches：分行去重時保留載入順序
import java.util.Map;
import java.util.Properties;

import com.ubot.kyc.comm.MailServiceThread;
import com.ubot.kyc.common.CurrentDate;
import com.ubot.kyc.db.CustDao;
import com.ubot.kyc.db.CustVo;
import com.ubot.kyc.db.DbUtil;
import com.ubot.kyc.db.FlowDao;
import com.ubot.kyc.db.FlowLogDao;
import com.ubot.kyc.db.ICTIDao;
import com.ubot.kyc.db.ICTIVo;
import com.ubot.kyc.db.RDDDao;
import com.ubot.kyc.db.RPT_CDDDao;
import com.ubot.kyc.db.RPT_CDDVo;
import com.ubot.kyc.db.VirtualAccountDao;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

public class WeekReportBig5 {
	static final char SBC_SPACE = 12288;
	static final String UTF8_BOM = "\uFEFF";
	static Connection con = null;
	static ICTIDao iDao = new ICTIDao();
	static ICTIVo iVo = null;
	static CustDao custDao = new CustDao();
	static CustVo custVo = null;
	static RPT_CDDDao dao = new RPT_CDDDao();
	static RPT_CDDVo vo = null;
	static RDDDao rDDDao = new RDDDao();
	static boolean rDDRs = false;
	static FlowDao flowDao = new FlowDao();
	static FlowLogDao flowLogDao = new FlowLogDao();
	static VirtualAccountDao virtualAccountDao = new VirtualAccountDao();
	static int pageY = 1;
	static int pageN = 1;
	static int line = 0;
	static int cnt = 0;
	static Map<Integer, String> map = new HashMap<Integer, String>();
	/*static Map<Integer, String> map01 = new HashMap<Integer, String>();
	static Map<Integer, String> map02 = new HashMap<Integer, String>();
	static Map<Integer, String> map03 = new HashMap<Integer, String>();
	static Map<Integer, String> map04 = new HashMap<Integer, String>();
	static Map<Integer, String> map05 = new HashMap<Integer, String>();
	static Map<Integer, String> map06 = new HashMap<Integer, String>();
	static Map<Integer, String> map07 = new HashMap<Integer, String>();
	static Map<Integer, String> map08 = new HashMap<Integer, String>();
	static Map<Integer, String> map09 = new HashMap<Integer, String>();*/
	static Map<Integer, String> mapBranch = new HashMap<Integer, String>();
	static String str01 = "";
	static String str02 = "";
	static String str03 = "";
	static String str04 = "";
	static String str05 = "";
	static String str06 = "";
	static String str07 = "";
	static String str08 = "";
	static String str09 = "";
	static CurrentDate cd = new CurrentDate();
	static FileWriter fw0 = null;
	static FileWriter fw1 = null;
	static FileWriter fw2 = null;
	static FileWriter fw3 = null;
	static FileWriter fw4 = null;
	static FileWriter fw5 = null;
	static FileWriter fw6 = null;
	static FileWriter fw7 = null;
	static FileWriter fw8 = null;
	static FileWriter fw01 = null;
	static FileWriter fw02 = null;
	static FileWriter fw03 = null;
	static FileWriter fw04 = null;
	static FileWriter fw05 = null;
	static FileWriter fw06 = null;
	static FileWriter fw07 = null;
	static FileWriter fw08 = null;
	static FileWriter fw09 = null;
	static FileWriter fwCDD = null;
	static boolean hasUnassignedBranch = false;
	static String msg = "";
	
	public void WeekRpt() {
		char changePage = (char)12;
		con = getConnection();

		dao.deleteCDDY(con);
		dao.deleteCDDN(con);
		
		File fAllY = null;
		File fAllN = null;
		File fY = null;
		File fN = null;
		File path = new File("D:\\weekRpt");
		DataOutputStream outputY = null;
		DataOutputStream outputN = null;
		DataOutputStream outputAllY = null;
		DataOutputStream outputAllN = null;
		LineNumberReader lineNumberReaderY = null;
		LineNumberReader lineNumberReaderN = null;
		/*Clock clock = Clock.systemUTC();
		MinguoDate hidate = MinguoDate.now(clock); 
		String dateStr = hidate.toString().replace("Minguo ROC ", "");
		String year = dateStr.split("-")[0];
		String month = dateStr.split("-")[1];
		String date = dateStr.split("-")[2];*/
		String year = cd.getMinguo();
		String month = cd.getMonth();
		String date = cd.getDay();
	
		String block0 = "";
		String block1 = "";
		String block2 = "";
		String block3 = "";
		String block4 = "";
		
		/*properties*/
		Properties properties = new Properties();
		String configFile = "File.properties";
		String branchStr = "";
		String mailto = "";	
		File cFile = new File("D:/RPT_CDD/CDD"+(cd.getDate().replaceAll("-", "")));
		if(!cFile.exists()) {cFile.mkdir();}
		// 未派名單每次執行都重產，避免同日重跑時混到前一次資料。
		File unassignedFile = new File("D:/RPT_CDD/CDDN_CDDY_UNASSIGNED"+(cd.getDate().replaceAll("-", "")));
		if(!unassignedFile.exists()) {unassignedFile.mkdir();}
		File[] oldUnassignedFiles = unassignedFile.listFiles();
		if(oldUnassignedFiles != null) {
			for(int i=0;i<oldUnassignedFiles.length;i++) {
				oldUnassignedFiles[i].delete();
			}
		}
		File oldUnassignedZip = new File("D:/RPT_CDD/CDDN_CDDY_UNASSIGNED" + (cd.getDate().replaceAll("-", "")) + ".zip");
		if(oldUnassignedZip.exists()) {oldUnassignedZip.delete();}
		System.out.println("start!");
		addLineMsg("開始時間：" + getDateTimeMicroSec());	
			
		try {
			properties.load(new FileInputStream(configFile));
			branchStr = properties.getProperty("BRANCHSTR").trim();
			mailto = properties.getProperty("MAILTO").trim();
			map = dao.cDDMap(branchStr, con);
			
			// RPT_BRA 載入後標準化：907→900、trim、去重，避免仍建立 907CDDY／907CDDN.DAT
			mapBranch = normalizeReportBranches(dao.cDDBranch(con));
			for(int j=0;j<mapBranch.size();j++) {
				fAllY = new File("D:\\weekRpt\\" + mapBranch.get(j) + "CDDY.DAT");
				fAllY.createNewFile();
				outputAllY = new DataOutputStream(new FileOutputStream(fAllY, true));
				outputAllY.write(padLeft(changePage + "", 35, SBC_SPACE).getBytes("big5"));
				outputAllY.write(padLeft("已更新基本資料之定期盡職審查報表", 40, SBC_SPACE).getBytes("big5"));
				outputAllY.writeUTF("\r\n");
				outputAllY.write(padLeft("", 37, SBC_SPACE).getBytes("big5"));
				outputAllY.write(padLeft("（本報表保存年限為五年）", 40, SBC_SPACE).getBytes("big5"));
				outputAllY.writeUTF("\r\n");
				outputAllY.write(padLeft("報表代號：CDDY", 50, SBC_SPACE).getBytes("big5"));
				outputAllY.writeUTF("\r\n");
				outputAllY.write(padLeft("歸屬單位：" + mapBranch.get(j), 75, ' ').getBytes("big5"));
				outputAllY.write(padLeft(year+"年"+month+"月"+date+"日", 41, SBC_SPACE).getBytes("big5"));
				outputAllY.write(padLeft("頁次：1", 4, SBC_SPACE).getBytes("big5"));
				outputAllY.writeUTF("\r\n");
				outputAllY.writeUTF("\r\n");
				outputAllY.write(padLeft("統編", 12, SBC_SPACE).getBytes("big5"));
				outputAllY.write(padLeft("定審到期日", 12, SBC_SPACE).getBytes("big5"));
				outputAllY.write(padLeft("更新資料方式", 16, SBC_SPACE).getBytes("big5"));
				outputAllY.write(padLeft("更新資料時間", 17, SBC_SPACE).getBytes("big5"));
				outputAllY.write(padLeft("AML-KYC定審作業", 20, SBC_SPACE).getBytes("big5"));
				outputAllY.write(padLeft("備註", 11, SBC_SPACE).getBytes("big5"));
				outputAllY.writeUTF("\r\n");
				outputAllY.write(padLeft("戶名", 21, SBC_SPACE).getBytes("big5"));
				outputAllY.write(padLeft("(個網/APP/臨櫃/數存/信用卡)", 42, SBC_SPACE).getBytes("big5"));
				outputAllY.write(padLeft("完成日期", 20, SBC_SPACE).getBytes("big5"));
				outputAllY.writeUTF("\r\n");
				outputAllY.writeUTF("\r\n");
				outputAllY.writeUTF("\r\n");
				
				fAllN = new File("D:\\weekRpt\\" + mapBranch.get(j) + "CDDN.DAT");
				fAllN.createNewFile();
				outputAllN = new DataOutputStream(new FileOutputStream(fAllN, true));
				outputAllN.write(padLeft(changePage + "", 34, SBC_SPACE).getBytes("big5"));
				outputAllN.write(padLeft("未更新基本資料之定期盡職審查報表", 40, SBC_SPACE).getBytes("big5"));
				outputAllN.writeUTF("\r\n");
				outputAllN.write(padLeft("報表代號：CDDN", 38, SBC_SPACE).getBytes("big5"));
				outputAllN.write(padLeft("（本報表保存年限為五年）", 40, SBC_SPACE).getBytes("big5"));
				outputAllN.writeUTF("\r\n");
				outputAllN.write(padLeft("歸屬單位：" + mapBranch.get(j), 40, SBC_SPACE).getBytes("big5"));
				outputAllN.write(padLeft(year+"年"+month+"月"+date+"日", 46, SBC_SPACE).getBytes("big5"));
				outputAllN.write(padLeft("頁次：1", 4, SBC_SPACE).getBytes("big5"));
				outputAllN.writeUTF("\r\n");
				outputAllN.writeUTF("\r\n");
				outputAllN.write(padLeft("統編", 11, SBC_SPACE).getBytes("big5"));
				outputAllN.write(padLeft("定審到期日", 12, SBC_SPACE).getBytes("big5"));
				outputAllN.write(padLeft("聯絡情形", 13, SBC_SPACE).getBytes("big5"));
				outputAllN.write(padLeft("聯繫客戶時間", 13, SBC_SPACE).getBytes("big5"));
				outputAllN.write(padLeft("AML-KYC定審作業", 17, SBC_SPACE).getBytes("big5"));
				outputAllN.write(padLeft("備註", 2, SBC_SPACE).getBytes("big5"));
				outputAllN.writeUTF("\r\n");
				outputAllN.write(padLeft("戶名", 50, SBC_SPACE).getBytes("big5"));
				outputAllN.write(padLeft("完成日期", 14, SBC_SPACE).getBytes("big5"));
				outputAllN.writeUTF("\r\n");
				outputAllN.writeUTF("\r\n");	
			}
			
			back:for(int i=0;i<map.size();i++) {
				cnt++;
				if(cnt%50000<=0) {System.out.println("5萬筆 : "+getDateTimeMicroSec());}
				vo = dao.findById(map.get(i), con);
				block0 = vo.getcId();
				block1 = vo.getName();
				block2 = vo.getTime();
				block3 = vo.getRisk();
				// 歸屬分行：先 trim，避免「907」含空白時對不到而無法併入 900
				block4 = vo.getBranch();
				if(block4 != null) {
					block4 = block4.trim();
				}
				// 907 分行已廢止，報表與名單一律視為 900
				if("907".equals(block4)) {
					block4 = "900";
				}
				// 801 不分 CDDN/CDDY，統一列入 CDD 未派名單並略過一般報表。
				if("801".equals(block4)) {
					hasUnassignedBranch = true;
					writeOutUnassigned(fwCDD, block0 + "|" + block2.substring(0, 10) + "|" + toSBC(block1).trim() + "|" + block3 + "|" + block4);
					continue back;
				}
				// 找不到可分派單位時不產一般報表，避免寫到不存在的分行檔。
				if(!isRptBranch(block4)) {
					continue back;
				}
				fY = new File("D:\\weekRpt\\" + block4 + "CDDY.DAT");
				fN = new File("D:\\weekRpt\\" + block4 + "CDDN.DAT");
				
					outputY = new DataOutputStream(new FileOutputStream(fY, true));					
					long fileYLength = fY.length();
					lineNumberReaderY = new LineNumberReader(new FileReader(fY));
					lineNumberReaderY.skip(fileYLength);
					int yLines = lineNumberReaderY.getLineNumber();
					if(yLines%54 == 0) {
						pageY = (yLines/54) + 1;
						outputY.write(padLeft(changePage + "", 35, SBC_SPACE).getBytes("big5"));
						outputY.write(padLeft("已更新基本資料之定期盡職審查報表", 40, SBC_SPACE).getBytes("big5"));
						outputY.writeUTF("\r\n");
						outputY.write(padLeft("", 37, SBC_SPACE).getBytes("big5"));
						outputY.write(padLeft("（本報表保存年限為五年）", 40, SBC_SPACE).getBytes("big5"));
						outputY.writeUTF("\r\n");
						outputY.write(padLeft("報表代號：CDDY", 50, SBC_SPACE).getBytes("big5"));
						outputY.writeUTF("\r\n");
						outputY.write(padLeft("歸屬單位：" + block4, 75, ' ').getBytes("big5"));
						outputY.write(padLeft(year+"年"+month+"月"+date+"日", 41, SBC_SPACE).getBytes("big5"));
						outputY.write(padLeft("頁次：" + pageY, 4, SBC_SPACE).getBytes("big5"));
						outputY.writeUTF("\r\n");
						outputY.writeUTF("\r\n");
						outputY.write(padLeft("統編", 12, SBC_SPACE).getBytes("big5"));
						outputY.write(padLeft("定審到期日", 12, SBC_SPACE).getBytes("big5"));
						outputY.write(padLeft("更新資料方式", 16, SBC_SPACE).getBytes("big5"));
						outputY.write(padLeft("更新資料時間", 17, SBC_SPACE).getBytes("big5"));
						outputY.write(padLeft("AML-KYC定審作業", 20, SBC_SPACE).getBytes("big5"));
						outputY.write(padLeft("備註", 11, SBC_SPACE).getBytes("big5"));
						outputY.writeUTF("\r\n");
						outputY.write(padLeft("戶名", 21, SBC_SPACE).getBytes("big5"));
						outputY.write(padLeft("(個網/APP/臨櫃/數存/信用卡)", 42, SBC_SPACE).getBytes("big5"));
						outputY.write(padLeft("完成日期", 20, SBC_SPACE).getBytes("big5"));
						outputY.writeUTF("\r\n");
						outputY.writeUTF("\r\n");
						outputY.writeUTF("\r\n");
					}
					outputN = new DataOutputStream(new FileOutputStream(fN, true));
					long fileNLength = fN.length();
					lineNumberReaderN = new LineNumberReader(new FileReader(fN));
					lineNumberReaderN.skip(fileNLength);
					int nLines = lineNumberReaderN.getLineNumber();
					if(nLines%51 == 0) {
						pageN = (nLines/51) + 1;
						outputN.write(padLeft(changePage + "", 34, SBC_SPACE).getBytes("big5"));
						outputN.write(padLeft("未更新基本資料之定期盡職審查報表", 40, SBC_SPACE).getBytes("big5"));
						outputN.writeUTF("\r\n");
						outputN.write(padLeft("報表代號：CDDN", 38, SBC_SPACE).getBytes("big5"));
						outputN.write(padLeft("（本報表保存年限為五年）", 40, SBC_SPACE).getBytes("big5"));
						outputN.writeUTF("\r\n");
						outputN.write(padLeft("歸屬單位：" + block4, 40, SBC_SPACE).getBytes("big5"));
						outputN.write(padLeft(year+"年"+month+"月"+date+"日", 46, SBC_SPACE).getBytes("big5"));
						outputN.write(padLeft("頁次：" + pageN, 4, SBC_SPACE).getBytes("big5"));
						outputN.writeUTF("\r\n");
						outputN.writeUTF("\r\n");
						outputN.write(padLeft("統編", 11, SBC_SPACE).getBytes("big5"));
						outputN.write(padLeft("定審到期日", 12, SBC_SPACE).getBytes("big5"));
						outputN.write(padLeft("聯絡情形", 13, SBC_SPACE).getBytes("big5"));
						outputN.write(padLeft("聯繫客戶時間", 13, SBC_SPACE).getBytes("big5"));
						outputN.write(padLeft("AML-KYC定審作業", 17, SBC_SPACE).getBytes("big5"));
						outputN.write(padLeft("備註", 2, SBC_SPACE).getBytes("big5"));
						outputN.writeUTF("\r\n");
						outputN.write(padLeft("戶名", 50, SBC_SPACE).getBytes("big5"));
						outputN.write(padLeft("完成日期", 14, SBC_SPACE).getBytes("big5"));
						outputN.writeUTF("\r\n");
						outputN.writeUTF("\r\n");				
					};
						int val = 2;
						if(dao.existCDD(block0, branchStr, con)) {
							if(custDao.existCust(block0, con)) {
								val = 0;
							} else {
								val = 1;
							}
						}
						
						String rs = "";
						custVo = custDao.findById(block0, con);
						String time = custVo.getEditTime();

						switch (val) {
						case 0:
							/*吃檔案判斷*/
//							rs = compare(time, block[0], block[3]) ? "CDDY" : (block[3].equals("H") ? "CDDN" : "N");
							rs = compare(time, block0, block3) ? "CDDN" : "CDDY";
					
							switch (rs) {
							/*若執行時段為1日~15日，CDDY需排除完成定審之名單*/
							case "CDDY":
								rDDRs = (rDDDao.existRarTime(block0, getLastMonth() + "-15", con)) || (flowDao.existEndTime(block0, getLastMonth() + "-15", con)) || (flowLogDao.existEndTime(block0, getLastMonth() + "-15", con));
								if(rDDRs) {continue back;}
								if(block3.equals("L")) {continue back;}
								if(!block4.equals("104") && !block4.equals("911")) {
									if(virtualAccountDao.existVA(block0, con)) {
										outputY.write(padLeft("★"+block0, 23, ' ').getBytes("big5"));
									} else {
										outputY.write(padLeft(block0, 24, ' ').getBytes("big5"));								
									}									
									outputY.write(padLeft(block2.substring(0, 10), 18, SBC_SPACE).getBytes("big5"));
									outputY.write(padLeft(chgUId(custVo.getUId()), 13, SBC_SPACE).getBytes("big5"));
									outputY.write(padLeft(time, 72, ' ').getBytes("big5"));									
									outputY.writeUTF("\r\n");
									outputY.write(padLeft(toSBC(block1), 100, SBC_SPACE).getBytes("big5"));
									outputY.writeUTF("\r\n");
									outputY.writeUTF("\r\n");
								} 
//								else {
									if(block3.equals("H")) {
										writeOut(fw0, "CDDY_H" , block0 + "|" + block2.substring(0, 10) + "|" + chgUId(custVo.getUId()) + "|" + time + "|" + toSBC(block1).trim() + "|" + block4);
									} else if(block3.equals("M")) {
										writeOut(fw1, "CDDY_M" , block0 + "|" + block2.substring(0, 10) + "|" + chgUId(custVo.getUId()) + "|" + time + "|" + toSBC(block1).trim() + "|" + block4);
									} else if(block3.equals("L")) {
										writeOut(fw6, "CDDY_L" , block0 + "|" + block2.substring(0, 10) + "|" + chgUId(custVo.getUId()) + "|" + time + "|" + toSBC(block1).trim() + "|" + block4);
									}
//								}
								
								custDao.insertCDDY(block0, con);
								break;
							case "CDDN":
								if(!block4.equals("104") && !block4.equals("911") && !block3.equals("L")) {
									if(virtualAccountDao.existVA(block0, con)) {
										outputN.write(padLeft("★"+block0, 21, ' ').getBytes("big5"));
									} else {
										outputN.write(padLeft(block0, 22, ' ').getBytes("big5"));							
									}									
									outputN.write(padLeft(block2.substring(0, 10), 17, SBC_SPACE).getBytes("big5"));			
									outputN.write(padLeft("配合/聯絡未果/拒絕配合", 14, SBC_SPACE).getBytes("big5"));
									outputN.write(padLeft("1.", 14, SBC_SPACE).getBytes("big5"));
									outputN.write(padLeft("   /     /", 19, SBC_SPACE).getBytes("big5"));									
									outputN.writeUTF("\r\n");
									
									if(toSBC(block1).length() > 66) {
										outputN.write(padLeft(toSBC(block1).substring(0, 33), 36, SBC_SPACE).getBytes("big5"));
										outputN.write(padLeft("2.", 14, SBC_SPACE).getBytes("big5"));
										outputN.writeUTF("\r\n");
										outputN.write(padLeft(toSBC(block1).substring(33, 66), 36, SBC_SPACE).getBytes("big5"));
										outputN.write(padLeft("3.", 18, SBC_SPACE).getBytes("big5"));
										outputN.writeUTF("\r\n");
										outputN.write(padLeft(toSBC(block1).substring(66, toSBC(block1).length()), 50, SBC_SPACE).getBytes("big5"));
										outputN.writeUTF("\r\n");
									} else if(toSBC(block1).length() > 33) {
										outputN.write(padLeft(toSBC(block1).substring(0, 33), 36, SBC_SPACE).getBytes("big5"));
										outputN.write(padLeft("2.", 14, SBC_SPACE).getBytes("big5"));
										outputN.writeUTF("\r\n");
										outputN.write(padLeft(toSBC(block1).substring(33, toSBC(block1).length()), 36, SBC_SPACE).getBytes("big5"));
										outputN.write(padLeft("3.", 15, SBC_SPACE).getBytes("big5"));
										outputN.writeUTF("\r\n");
										outputN.writeUTF("\r\n");
									} else {
										outputN.write(padLeft(toSBC(block1), 36, SBC_SPACE).getBytes("big5"));				
										outputN.write(padLeft("2.", 14, SBC_SPACE).getBytes("big5"));
										outputN.writeUTF("\r\n");
										outputN.write(padLeft("", 36, SBC_SPACE).getBytes("big5"));
										outputN.write(padLeft("3.", 15, SBC_SPACE).getBytes("big5"));
										outputN.writeUTF("\r\n");
										outputN.writeUTF("\r\n");
									}
								} 
//								else {
									if(block3.equals("H")) {
										writeOut(fw2, "CDDN_H" , block0 + "|" + block2.substring(0, 10) + "|" + toSBC(block1).trim() + "|" + block4);
									} else if(block3.equals("M")) {
										writeOut(fw3, "CDDN_M" , block0 + "|" + block2.substring(0, 10) + "|" + toSBC(block1).trim() + "|" + block4);
									} else if(block3.equals("L")) {
										writeOut(fw7, "CDDN_L" , block0 + "|" + block2.substring(0, 10) + "|" + toSBC(block1).trim() + "|" + block4);
									}
//								}
								custDao.insertCDDN(block0, con);
								break;
							}
							break;
						case 1:
							if(!block4.equals("104") && !block4.equals("911") && !block3.equals("L")) {
								if(virtualAccountDao.existVA(block0, con)) {
									outputN.write(padLeft("★"+block0, 21, ' ').getBytes("big5"));
								} else {
									outputN.write(padLeft(block0, 22, ' ').getBytes("big5"));
								}															
								outputN.write(padLeft(block2.substring(0, 10), 17, SBC_SPACE).getBytes("big5"));			
								outputN.write(padLeft("配合/聯絡未果/拒絕配合", 14, SBC_SPACE).getBytes("big5"));
								outputN.write(padLeft("1.", 14, SBC_SPACE).getBytes("big5"));
								outputN.write(padLeft("   /     /", 19, SBC_SPACE).getBytes("big5"));							
								outputN.writeUTF("\r\n");
								
								if(toSBC(block1).length() > 66) {
									outputN.write(padLeft(toSBC(block1).substring(0, 33), 36, SBC_SPACE).getBytes("big5"));
									outputN.write(padLeft("2.", 14, SBC_SPACE).getBytes("big5"));
									outputN.writeUTF("\r\n");
									outputN.write(padLeft(toSBC(block1).substring(33, 66), 36, SBC_SPACE).getBytes("big5"));
									outputN.write(padLeft("3.", 18, SBC_SPACE).getBytes("big5"));
									outputN.writeUTF("\r\n");
									outputN.write(padLeft(toSBC(block1).substring(66, toSBC(block1).length()), 50, SBC_SPACE).getBytes("big5"));
									outputN.writeUTF("\r\n");
								} else if(toSBC(block1).length() > 33) {
									outputN.write(padLeft(toSBC(block1).substring(0, 33), 36, SBC_SPACE).getBytes("big5"));
									outputN.write(padLeft("2.", 14, SBC_SPACE).getBytes("big5"));
									outputN.writeUTF("\r\n");
									outputN.write(padLeft(toSBC(block1).substring(33, toSBC(block1).length()), 36, SBC_SPACE).getBytes("big5"));
									outputN.write(padLeft("3.", 15, SBC_SPACE).getBytes("big5"));
									outputN.writeUTF("\r\n");
									outputN.writeUTF("\r\n");
								} else {
									outputN.write(padLeft(toSBC(block1), 36, SBC_SPACE).getBytes("big5"));				
									outputN.write(padLeft("2.", 14, SBC_SPACE).getBytes("big5"));
									outputN.writeUTF("\r\n");
									outputN.write(padLeft("", 36, SBC_SPACE).getBytes("big5"));
									outputN.write(padLeft("3.", 15, SBC_SPACE).getBytes("big5"));
									outputN.writeUTF("\r\n");
									outputN.writeUTF("\r\n");
								}
							} 
//							else {
								if(block3.equals("H")) {
									writeOut(fw4, "CDDN_H" , block0 + "|" + block2.substring(0, 10) + "|" + toSBC(block1).trim() + "|" + block4);
								} else if(block3.equals("M")) {
									writeOut(fw5, "CDDN_M" , block0 + "|" + block2.substring(0, 10) + "|" + toSBC(block1).trim() + "|" + block4);
								} else if(block3.equals("L")) {
									writeOut(fw8, "CDDN_L" , block0 + "|" + block2.substring(0, 10) + "|" + toSBC(block1).trim() + "|" + block4);
								}
//							}
							custDao.insertCDDN(block0, con);
							break;	
						case 2:
							break;
						default:
							break;
						}
			}	
			/*map01 = dao.getCDDN(con);
			for(int k=0;k<map01.size();k++) {
				str01 += map01.get(k);
			}
			writeOut(fw01, "CDDN_total", str01);
			map02 = dao.getCDDY(con);
			for(int k=0;k<map02.size();k++) {
				str02 += map02.get(k);
			}
			writeOut(fw02, "CDDY_total", str02);
			map03 = dao.getCDDN_H(con);
			for(int k=0;k<map03.size();k++) {
				str03 += map03.get(k);
			}
			writeOut(fw03, "CDDN_H_total", str03);
			map04 = dao.getCDDY_H(con);
			for(int k=0;k<map04.size();k++) {
				str04 += map04.get(k);
			}
			writeOut(fw04, "CDDY_H_total", str04);
			map05 = dao.getCDDN_M(con);
			for(int k=0;k<map05.size();k++) {
				str05 += map05.get(k);
			}
			writeOut(fw05, "CDDN_M_total", str05);
			map06 = dao.getCDDY_M(con);
			for(int k=0;k<map06.size();k++) {
				str06 += map06.get(k);
			}
			writeOut(fw06, "CDDY_M_total", str06);
			map07 = dao.getCDDN_L(con);
			for(int k=0;k<map07.size();k++) {
				str07 += map07.get(k);
			}
			writeOut(fw07, "CDDN_L_total", str07);
			map08 = dao.getEdit(con);
			for(int k=0;k<map08.size();k++) {
				str08 += map08.get(k);
			}
			writeOut(fw08, "EDITTIME", str08);
			map09 = dao.getTag(con);
			for(int k=0;k<map09.size();k++) {
				str09 += map09.get(k);
			}
			writeOut(fw09, "0_1_2", str09);*/
			if(path.isDirectory()) {
				String word1 = "一、客戶之歸屬單位應於定審到期日前完成AML-KYC之定審表。";
				String word2 = "二、如涉及疑似洗錢或資恐交易者，應依本行「疑似洗錢或資恐交易審查及申報管理程序」規定通報專責單位。";
				String word3 = "三、報表為機密文件，單位主管應指派專人以專卷保管。";
				String word4 = "四、統編前加註★者為客戶有申請虛擬帳號，另應填寫「虛擬帳號客戶盡職調查表」，評估是否同意申請人續用虛擬帳號繳款服務。";
				String wordN1 = "一、歸屬單位應於定審到期日前聯繫客戶並完成AML-KYC之定審作業。";
				String wordN2 = "二、如涉及疑似洗錢或資恐交易者，應依本行「疑似洗錢或資恐交易審查及申報管理程序」規定通報專責單位。";
				String wordN3 = "三、報表為機密文件，單位主管應指派專人以專卷保管。";
				String wordN4 = "四、統編前加註★者為客戶有申請虛擬帳號，另應填寫「虛擬帳號客戶盡職調查表」，評估是否同意申請人續用虛擬帳號繳款服務。";
				File results[] = path.listFiles();
				LineNumberReader lineNumberReaderYY = null;
				LineNumberReader lineNumberReaderNN = null;
				if(results != null) {
					for(int i=0;i<results.length;i++) {
						if(results[i].getName().endsWith("Y.DAT")) {
							outputY = new DataOutputStream(new FileOutputStream(results[i], true));
							long fileYYLength = results[i].length();	
							lineNumberReaderYY = new LineNumberReader(new FileReader(results[i]));
							lineNumberReaderYY.skip(fileYYLength);
							int yLines = lineNumberReaderYY.getLineNumber();
							if(((yLines%54) > 41) || ((yLines>=54) && (yLines%54==0))) {
								outputY.write(padLeft(changePage + "", 35, SBC_SPACE).getBytes("big5"));
								outputY.write(padLeft("已更新基本資料之定期盡職審查報表", 40, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.write(padLeft("", 37, SBC_SPACE).getBytes("big5"));
								outputY.write(padLeft("（本報表保存年限為五年）", 40, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.write(padLeft("報表代號：CDDY", 50, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.write(padLeft("歸屬單位：" + results[i].getName().substring(0, 3), 75, ' ').getBytes("big5"));
								outputY.write(padLeft(year+"年"+month+"月"+date+"日", 41, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								//
								outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");
								//
								outputY.writeUTF("\r\n");
								outputY.write(padLeft("", 20, SBC_SPACE).getBytes("big5"));
								outputY.write(padLeft("經辦", 20, SBC_SPACE).getBytes("big5"));
								outputY.write(padLeft("洗錢防制督導主管", 30, SBC_SPACE).getBytes("big5"));
								outputY.write(padLeft("單位主管", 4, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");
								outputY.write(padLeft("註：", 20, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");
								outputY.write(padLeft(word1, 58, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");
								outputY.write(padLeft(word2, 58, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");
								outputY.write(padLeft(word3, 58, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");
								outputY.write(padLeft(word4, 58, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");
							} else {	
								while((yLines%54) < 41) {
									outputY.writeUTF("\r\n");
									yLines++;
								}							
								outputY.writeUTF("\r\n");
								outputY.write(padLeft("", 20, SBC_SPACE).getBytes("big5"));
								outputY.write(padLeft("經辦", 20, SBC_SPACE).getBytes("big5"));
								outputY.write(padLeft("洗錢防制督導主管", 30, SBC_SPACE).getBytes("big5"));
								outputY.write(padLeft("單位主管", 4, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");
								outputY.write(padLeft("註：", 20, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");
								outputY.write(padLeft(word1, 58, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");
								outputY.write(padLeft(word2, 58, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");
								outputY.write(padLeft(word3, 58, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");
								outputY.write(padLeft(word4, 58, SBC_SPACE).getBytes("big5"));
								outputY.writeUTF("\r\n");
								outputY.writeUTF("\r\n");
							}
						}						
					}
					for(int i=0;i<results.length;i++) {
						if(results[i].getName().endsWith("N.DAT")) {
							outputN = new DataOutputStream(new FileOutputStream(results[i], true));
							long fileNNLength = results[i].length();				
							lineNumberReaderNN = new LineNumberReader(new FileReader(results[i]));
							lineNumberReaderNN.skip(fileNNLength);
							int nLines = lineNumberReaderNN.getLineNumber();
							//System.out.println(results[i].getName() + "---" + nLines);
							if(((nLines%51) > 38) || ((nLines>=51) && (nLines%51==0))) {	
								//System.out.println("A---A : " + (nLines%51));
								outputN.write(padLeft(changePage + "", 34, SBC_SPACE).getBytes("big5"));
								outputN.write(padLeft("未更新基本資料之定期盡職審查報表", 40, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								outputN.write(padLeft("報表代號：CDDN", 38, SBC_SPACE).getBytes("big5"));
								outputN.write(padLeft("（本報表保存年限為五年）", 40, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								outputN.write(padLeft("歸屬單位：" + results[i].getName().substring(0, 3), 40, SBC_SPACE).getBytes("big5"));
								outputN.write(padLeft(year+"年"+month+"月"+date+"日", 46, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								//
								outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");/*outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");outputN.writeUTF("\r\n");*/
								//
								outputN.writeUTF("\r\n");
								outputN.write(padLeft("", 20, SBC_SPACE).getBytes("big5"));
								outputN.write(padLeft("經辦", 20, SBC_SPACE).getBytes("big5"));
								outputN.write(padLeft("洗錢防制督導主管", 30, SBC_SPACE).getBytes("big5"));
								outputN.write(padLeft("單位主管", 4, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");
								outputN.write(padLeft("註：", 20, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");
								outputN.write(padLeft(wordN1, 100, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");
								outputN.write(padLeft(wordN2, 60, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");
								outputN.write(padLeft(wordN3, 60, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");
								outputN.write(padLeft(wordN4, 60, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");
							} else {
								while((nLines%51) <= 38) {
									outputN.writeUTF("\r\n");
									nLines++;
								}

								outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");
								outputN.write(padLeft("", 20, SBC_SPACE).getBytes("big5"));
								outputN.write(padLeft("經辦", 20, SBC_SPACE).getBytes("big5"));
								outputN.write(padLeft("洗錢防制督導主管", 30, SBC_SPACE).getBytes("big5"));
								outputN.write(padLeft("單位主管", 4, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");
								outputN.write(padLeft("註：", 20, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");
								outputN.write(padLeft(wordN1, 100, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");
								outputN.write(padLeft(wordN2, 60, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");
								outputN.write(padLeft(wordN3, 60, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");
								outputN.write(padLeft(wordN4, 60, SBC_SPACE).getBytes("big5"));
								outputN.writeUTF("\r\n");
								outputN.writeUTF("\r\n");
							}
						}						
					}
				}
			}
		} catch (UnsupportedEncodingException e) {		
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if(lineNumberReaderN != null) {
				try {
					lineNumberReaderN.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(lineNumberReaderY != null) {
				try {
					lineNumberReaderY.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(outputN != null) {
				try {
					outputN.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(outputY != null) {
				try {
					outputY.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			/*if(br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}*/
			if(con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			//壓縮--------
//			ArrayList<File> filesToAdd = new ArrayList<File>();
			/*File[] file = {new File("D:/RPT_CDD/CDDN_H" + (cd.getDate().replaceAll("-", "")) + ".txt"),new File("D:/RPT_CDD/CDDN_M" + (cd.getDate().replaceAll("-", "")) + ".txt"), new File("D:/RPT_CDD/CDDN_L" + (cd.getDate().replaceAll("-", "")) + ".txt"), new File("D:/RPT_CDD/CDDY_H" + (cd.getDate().replaceAll("-", "")) + ".txt"), new File("D:/RPT_CDD/CDDY_M" + (cd.getDate().replaceAll("-", "")) + ".txt")};
			for(int i=0;i<file.length;i++) {
				if(file[i].exists()) {System.out.println("file[i] : " + file[i]);filesToAdd.add(file[i]);}
			}*/
			File file = new File("D:/RPT_CDD/CDD"+(cd.getDate().replaceAll("-", "")));
			if(!file.exists()) {file.mkdir();}
//			File file = new File("D:/RPT_CDD/CDD");
//			filesToAdd.add(file);
			String targetZip = "D:/RPT_CDD/CDD" + (cd.getDate().replaceAll("-", "")) + ".zip";
			String password = "2826";
			AddFilesWithAESEncryption(targetZip, file, password);			
			
			System.out.println("done!");
			addLineMsg("結束時間：" + getDateTimeMicroSec());
			infoAP(mailto, targetZip);
			// 只有實際產生未派資料時，才另外寄出未派名單。
			if(hasUnassignedBranch) {
				File unassignedZipFile = new File("D:/RPT_CDD/CDDN_CDDY_UNASSIGNED"+(cd.getDate().replaceAll("-", "")));
				String unassignedZip = "D:/RPT_CDD/CDDN_CDDY_UNASSIGNED" + (cd.getDate().replaceAll("-", "")) + ".zip";
				AddFilesWithAESEncryption(unassignedZip, unassignedZipFile, password);
				infoUnassignedAP(mailto, unassignedZip);
			}
		}
	}	
	
	private static void AddFilesWithAESEncryption(String targetZip,File file,String password) {    
        try{
            ZipFile zipFile = new ZipFile(targetZip);
//            zipFile.addFolder(path, parameters);
            
            ZipParameters parameters =new ZipParameters();
            /*parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
              
            parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL); */
            parameters.setEncryptFiles(true);
              
            parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
              
  
            parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
            parameters.setPassword(password);
//            zipFile.addFiles(filesToAdd, parameters);
            zipFile.addFolder(file, parameters);
        } catch (ZipException e) {
			e.printStackTrace();
		}
    }



	private String chgUId(String uId) {
		switch (uId) {
		case "1049999":
			uId = "客服";
			break;
		case "1049998":
			uId = "個網";
			break;
		case "1049997":
			uId = "數存";
			break;
		case "1049996":
			uId = "APP";
			break;
		case "9118881":
			uId = "信用卡";
			break;
		case "8880001":
			uId = "數存";
			break;
		default:
			uId = "臨櫃";
			break;
		}
		return uId;
	}
	
	private static void writeOut(FileWriter fw, String str, String line) {
		File file = new File("D:/RPT_CDD/CDD"+(cd.getDate().replaceAll("-", ""))+"/" + str + (cd.getDate().replaceAll("-", "")) + ".txt");		
		try {
			if(fw == null) {
				fw = new FileWriter(file, true);
			}			
		} catch (IOException e) {
			e.printStackTrace();
		}
		PrintWriter pw = new PrintWriter(fw);
		pw.println(line);
		pw.flush();
		try {
			fw.flush();
			fw.close();
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}

	private static void writeOutUnassigned(FileWriter fw, String line) {
		// RptMain 同時涵蓋 CDDN 與 CDDY，檔名用 CDDN_CDDY 做區隔。
		File file = new File("D:/RPT_CDD/CDDN_CDDY_UNASSIGNED"+(cd.getDate().replaceAll("-", ""))+"/CDDN_CDDY_UNASSIGNED" + (cd.getDate().replaceAll("-", "")) + ".txt");
		try {
			if(fw == null) {
				fw = new FileWriter(file, true);
			}			
		} catch (IOException e) {
			e.printStackTrace();
		}
		PrintWriter pw = new PrintWriter(fw);
		pw.println(line);
		pw.flush();
		try {
			fw.flush();
			fw.close();
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	private boolean compare(String data, String uId, String ra) {
		boolean result = false;
		CurrentDate cd = new CurrentDate();
		Calendar rightNow = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		if(data == null) {
			result = true;
		} else {
			if(data.equals("")) {
				result = true;
			}else {
				if(data.length() == 8) {
					data = data.substring(0, 4)+"-"+data.substring(4, 6)+"-10";
				}
				try {
					Date date2 = sdf.parse(cd.getDate());
					Date date = sdf.parse(data);
						switch (ra) {
						case "H":
							rightNow.setTime(date);
							rightNow.add(Calendar.MONTH, +3);
							Date h = rightNow.getTime();
							if(h.before(date2) || h.equals(date2)) {
								result = true;
							}
							break;
						case "M":
							rightNow.setTime(date);
							rightNow.add(Calendar.MONTH, +6);
							Date h2 = rightNow.getTime();
							if(h2.before(date2) || h2.equals(date2)) {
								result = true;
							}
							break;
						case "L":
							rightNow.setTime(date);
							rightNow.add(Calendar.MONTH, +6);
							Date h3 = rightNow.getTime();
							if(h3.before(date2) || h3.equals(date2)) {
								result = true;
							}
							break;
						default:
							break;
						}
					
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	
	private static Connection getConnection() {
		return DbUtil.getConnection();
	}
	private String getDateTimeMicroSec() {
		CurrentDate date = new CurrentDate();
		return date.getDateTimeMicroSec();
	}
	private String padLeft(String src, int len, char ch) {
		int diff = len - src.length();
		if(diff <= 0) {
			return src;
		}
		char[] charr = new char[len];
		System.arraycopy(src.toCharArray(), 0, charr, 0, src.length());
		for(int i = src.length(); i < len; i++) {
			charr[i] = ch;
		}
		return new String(charr);
	}
	
	public String toSBC(String input) { // 轉全形
		char c[] = input.toCharArray();
		for (int i = 0; i < c.length; i++) {
			if (c[i] == ' ') {
				c[i] = '\u3000';
			} else if (c[i] < '\177') {
				c[i] = (char) (c[i] + 65248);
			}
		}
		return new String(c);
	}
	private static String getLastMonth() {
		Calendar cal = Calendar.getInstance();
	    cal.add(Calendar.MONTH, -1);
	    SimpleDateFormat dft = new SimpleDateFormat("yyyy-MM");
	    String lastMonth = dft.format(cal.getTime());
	    return lastMonth;
	}
	/** RPT_BRA 載入後整理：trim、907→900、分行去重（順序依首次出現）。 */
	private Map<Integer, String> normalizeReportBranches(Map<Integer, String> raw) {
		if(raw == null) {
			return new HashMap<Integer, String>();
		}
		LinkedHashSet<String> seen = new LinkedHashSet<String>();
		for(int j = 0; j < raw.size(); j++) {
			String b = raw.get(j);
			if(b == null) {
				continue;
			}
			b = b.trim();
			if(b.isEmpty()) {
				continue;
			}
			if("907".equals(b)) {
				b = "900"; // 與客戶迴圈 block4 規則一致
			}
			seen.add(b);
		}
		Map<Integer, String> out = new HashMap<Integer, String>();
		int idx = 0;
		for(String b : seen) {
			out.put(idx++, b);
		}
		return out;
	}
	// RPT_BRA 列到的分行才可走 DAT；104／911 特例（組長：免產 DAT，但主 zip txt 仍要有）
	private boolean isRptBranch(String branch) {
		if(branch == null) {
			return false;
		}
		String b = branch.trim(); // 與 block4 一致，避免比對 RPT_BRA 失敗
		if(b.isEmpty()) {
			return false;
		}
		// 104／911：組長確認免產 DAT，仍須進主 zip txt（未必在 RPT_BRA）
		if("104".equals(b) || "911".equals(b)) {
			return true;
		}
		for(int i=0;i<mapBranch.size();i++) {
			if(mapBranch.get(i).equals(b)) {
				return true;
			}
		}
		return false;
	}
	private static void infoAP(String mailto, String mailFile) {
		MailServiceThread mailt = new MailServiceThread("KYC", mailto, "CDD名單", msg, mailFile);
		mailt.start();			
	}
	// 未派名單使用獨立主旨，方便收件人和一般 CDD 名單區分。
	private static void infoUnassignedAP(String mailto, String mailFile) {
		MailServiceThread mailt = new MailServiceThread("KYC", mailto, "CDD未派名單", msg, mailFile);
		mailt.start();			
	}
	private static void addLineMsg(String str) {
		System.out.println(str);
		msg = msg + str + "\n";		
	}
}
