
public class DayRptMain {
	public static void main(String[] args) {
		DayReportAML152 dRpt = new DayReportAML152();
		dRpt.DayRpt();
		dRpt.mergeRptB();
		dRpt.mergeRptC();
		dRpt.toETL();
		dRpt.toETLThret();
//		dRpt.toETLPID();
	}
}
