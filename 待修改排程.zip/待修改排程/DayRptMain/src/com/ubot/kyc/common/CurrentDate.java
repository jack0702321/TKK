package com.ubot.kyc.common;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CurrentDate {

	public String getCurrentTaiwanDate() {
		Calendar c = Calendar.getInstance();
		c.roll(Calendar.YEAR, -1911);
		String a =new SimpleDateFormat("HH:mm:ss").format(c.getTime());
		return  String.format("%d-%02d-%02d %s",c.get(Calendar.YEAR),((int)c.get(Calendar.MONTH)+1),c.get(Calendar.DATE),a);
	}
		
	public String getDateTimeSec() {
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date().getTime());
	}
	
	public String getDateTimeMicroSec() {
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS").format(new Date().getTime());
	}
	
	public String getDate() {
		return new SimpleDateFormat("yyyy-MM-dd").format(new Date().getTime());
	}
	
	public String getYesterday() {
		return new SimpleDateFormat("yyyy-MM-dd").format(new Date(System.currentTimeMillis() - 1000*60*60*24).getTime());
	}
	
	public String getYesterDate() {
		return getMinguo()+new SimpleDateFormat("MMdd").format(new Date(System.currentTimeMillis() - 1000*60*60*24).getTime());
	}
	
	public String getYear() {
		return new SimpleDateFormat("yyyy").format(new Date().getTime());
	}
	
	public String getMinguo() {
		return Integer.toString(Integer.parseInt(getYear())-1911);
	}
	
	public String getMonth() {
		return new SimpleDateFormat("MM").format(new Date().getTime());
	}
	
	public String getDay() {
		return new SimpleDateFormat("dd").format(new Date().getTime());
	}
	
	public String getYesterDay() {
		return new SimpleDateFormat("dd").format(new Date(System.currentTimeMillis() - 1000*60*60*24).getTime());
	}
}
