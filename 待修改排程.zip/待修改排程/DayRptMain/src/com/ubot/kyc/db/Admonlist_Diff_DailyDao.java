package com.ubot.kyc.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class Admonlist_Diff_DailyDao {
	public Map<Integer, String> diffMap(Connection con) {
		String sql = "SELECT CID, DATATYPE FROM ADMONLIST_DIFF_DAILY WHERE DATADATE = CONVERT(varchar(10), GETDATE(), 23) AND PIDNY != 'Y' AND ACCCLSMARK != '1' AND JOINTNY !='Y' ORDER BY DATADATE,CID,DATATYPE DESC";
//		String sql = "SELECT CID, DATATYPE FROM ADMONLIST_DIFF_DAILY WHERE DATADATE = '2024-07-25' AND PIDNY != 'Y' AND ACCCLSMARK != '1' AND JOINTNY !='Y' ORDER BY DATADATE,CID,DATATYPE DESC";
		
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("CID") + "|" + rs.getString("DATATYPE"));
				cnt++;
			}
		} catch (SQLException sqlE) {			
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<Integer, String> pidNYMap(Connection con) {
		String sql = "SELECT CID, DATATYPE FROM ADMONLIST_DIFF_DAILY WHERE DATADATE = CONVERT(varchar(10), GETDATE(), 23) AND PIDNY = 'Y' AND ACCCLSMARK != '1' ORDER BY DATADATE,CID,DATATYPE DESC";	
//		String sql = "SELECT CID, DATATYPE FROM ADMONLIST_DIFF_DAILY WHERE DATADATE = '2024-07-25' AND PIDNY = 'Y' AND ACCCLSMARK != '1' ORDER BY DATADATE,CID,DATATYPE DESC";
		
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("CID") + "|" + rs.getString("DATATYPE"));
				cnt++;
			}
		} catch (SQLException sqlE) {			
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<Integer, String> jointNYMap(Connection con) {
		String sql = "SELECT CID, DATATYPE FROM ADMONLIST_DIFF_DAILY WHERE DATADATE = CONVERT(varchar(10), GETDATE(), 23) AND JOINTNY = 'Y' AND ACCCLSMARK != '1' ORDER BY DATADATE,CID,DATATYPE DESC";
//		String sql = "SELECT CID, DATATYPE FROM ADMONLIST_DIFF_DAILY WHERE DATADATE = '2024-07-25' AND JOINTNY = 'Y' AND ACCCLSMARK != '1' ORDER BY DATADATE,CID,DATATYPE DESC";
			
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("CID") + "|" + rs.getString("DATATYPE"));
				cnt++;
			}
		} catch (SQLException sqlE) {			
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Admonlist_Diff_DailyVo findById(String cId, Connection con) {
		String sql = "SELECT CID, NAME, DATATYPE, WARNINGDATE, EXPIREDATE, ISSUER, RMDBRANCH, BRFLAG FROM ADMONLIST_DIFF_DAILY WHERE CID = ? AND DATATYPE = ? AND DATADATE = CONVERT(varchar(10), GETDATE(), 23) AND PIDNY != 'Y' AND ACCCLSMARK != '1' AND JOINTNY !='Y' ORDER BY DATADATE,CID,DATATYPE DESC";
//		String sql = "SELECT CID, NAME, DATATYPE, WARNINGDATE, EXPIREDATE, ISSUER, RMDBRANCH, BRFLAG FROM ADMONLIST_DIFF_DAILY WHERE CID = ? AND DATATYPE = ? AND DATADATE = '2024-07-25' AND PIDNY != 'Y' AND ACCCLSMARK != '1' AND JOINTNY !='Y' ORDER BY DATADATE,CID,DATATYPE DESC";
		
		Admonlist_Diff_DailyVo vo = new Admonlist_Diff_DailyVo();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId.split("\\|")[0]);
			pstmt.setString(2, cId.split("\\|")[1]);
			rs = pstmt.executeQuery();
			while (rs.next()) {				
				vo.setcId(rs.getString("CID"));
				vo.setName(rs.getString("NAME"));
				vo.setDataType(rs.getString("DATATYPE"));
				vo.setWarningDate(rs.getString("WARNINGDATE"));
				vo.setExpireDate(rs.getString("EXPIREDATE"));
				vo.setIssuer(rs.getString("ISSUER"));
				vo.setRmdBranch(rs.getString("RMDBRANCH"));
				vo.setBrFlag(rs.getString("BRFLAG"));
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return vo;	
	}
	
	public Admonlist_Diff_DailyVo findByPId(String cId, Connection con) {		
		String sql = "SELECT CID, NAME, DATATYPE, WARNINGDATE, EXPIREDATE, ISSUER, RMDBRANCH, BRFLAG, PIDID FROM ADMONLIST_DIFF_DAILY WHERE CID = ? AND DATATYPE = ? AND DATADATE = CONVERT(varchar(10), GETDATE(), 23) AND PIDNY = 'Y' AND ACCCLSMARK != '1' ORDER BY DATADATE,CID,DATATYPE DESC";
//		String sql = "SELECT CID, NAME, DATATYPE, WARNINGDATE, EXPIREDATE, ISSUER, RMDBRANCH, BRFLAG, PIDID FROM ADMONLIST_DIFF_DAILY WHERE CID = ? AND DATATYPE = ? AND DATADATE = '2024-07-25' AND PIDNY = 'Y' AND ACCCLSMARK != '1' ORDER BY DATADATE,CID,DATATYPE DESC";
		
		Admonlist_Diff_DailyVo vo = new Admonlist_Diff_DailyVo();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId.split("\\|")[0]);
			pstmt.setString(2, cId.split("\\|")[1]);
			rs = pstmt.executeQuery();
			while (rs.next()) {				
				vo.setcId(rs.getString("CID"));
				vo.setName(rs.getString("NAME"));
				vo.setDataType(rs.getString("DATATYPE"));
				vo.setWarningDate(rs.getString("WARNINGDATE"));
				vo.setExpireDate(rs.getString("EXPIREDATE"));
				vo.setIssuer(rs.getString("ISSUER"));
				vo.setRmdBranch(rs.getString("RMDBRANCH"));
				vo.setBrFlag(rs.getString("BRFLAG"));
				vo.setPidId(rs.getString("PIDID"));
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return vo;	
	}
	
	public Admonlist_Diff_DailyVo findByJoint(String cId, Connection con) {		
		String sql = "SELECT CID, NAME, DATATYPE, WARNINGDATE, EXPIREDATE, ISSUER, RMDBRANCH, BRFLAG, JOINTID FROM ADMONLIST_DIFF_DAILY WHERE CID = ? AND DATATYPE = ? AND DATADATE = CONVERT(varchar(10), GETDATE(), 23) AND JOINTNY = 'Y' AND ACCCLSMARK != '1' ORDER BY DATADATE,CID,DATATYPE DESC";
//		String sql = "SELECT CID, NAME, DATATYPE, WARNINGDATE, EXPIREDATE, ISSUER, RMDBRANCH, BRFLAG, JOINTID FROM ADMONLIST_DIFF_DAILY WHERE CID = ? AND DATATYPE = ? AND DATADATE = '2024-07-25' AND JOINTNY = 'Y' AND ACCCLSMARK != '1' ORDER BY DATADATE,CID,DATATYPE DESC";
		
		Admonlist_Diff_DailyVo vo = new Admonlist_Diff_DailyVo();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId.split("\\|")[0]);
			pstmt.setString(2, cId.split("\\|")[1]);
			rs = pstmt.executeQuery();
			while (rs.next()) {				
				vo.setcId(rs.getString("CID"));
				vo.setName(rs.getString("NAME"));
				vo.setDataType(rs.getString("DATATYPE"));
				vo.setWarningDate(rs.getString("WARNINGDATE"));
				vo.setExpireDate(rs.getString("EXPIREDATE"));
				vo.setIssuer(rs.getString("ISSUER"));
				vo.setRmdBranch(rs.getString("RMDBRANCH"));
				vo.setBrFlag(rs.getString("BRFLAG"));
				vo.setJointId(rs.getString("JOINTID"));
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return vo;	
	}
	
	public Map<Integer, String> rptBranchB(Connection con) {
		String sql = "SELECT RMDBRANCH FROM RPT_DAYBRA2";
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("RMDBRANCH"));
				cnt++;
			}
		} catch (SQLException sqlE) {			
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<Integer, String> rptBranchC(Connection con) {
		String sql = "SELECT RMDBRANCH FROM RPT_DAYBRA";
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("RMDBRANCH"));
				cnt++;
			}
		} catch (SQLException sqlE) {			
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public boolean existBRA(String cId, Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM RPT_DAYBRA2 WHERE RMDBRANCH = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;		
	}
	
	
	public Map<String, String> toETL(Connection con) {
		String sql = "SELECT CID, 10001 'TEMPLATEID', CASE WHEN (DATATYPE = 'A' OR DATATYPE = 'U') THEN 'Y' WHEN (DATATYPE = 'D' OR DATATYPE = 'E') THEN 'N' END 'ANSWER', DATADATE FROM ADMONLIST_DIFF_DAILY WHERE DATADATE = CONVERT(char(10), getdate(), 120) AND PIDNY != 'Y' AND JOINTNY !='Y'";
		Map<String, String> map = new HashMap<String, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(String.valueOf(cnt),rs.getString("CID") + "|" + rs.getString("TEMPLATEID") + "|" + rs.getString("ANSWER") + "|" + rs.getString("DATADATE"));
				cnt++;
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<String, String> toETLThret(Connection con) {
		String sql = "SELECT THRET_ID_NO, 10004 'TEMPLATEID', 'Y' ANSWER, CONVERT(char(10), getdate(), 120) 'DATADATE' FROM THRETRIS WHERE THRET_YN = 'Y' AND DAILYDATE = CONVERT(char(10), getdate(), 120) AND (THRET_ID_NO NOT IN (SELECT THRET_ID_NO FROM THRETRIS WHERE DAILYDATE = CONVERT(char(10), getdate()-1, 120) AND THRET_YN = 'Y')) UNION (SELECT THRET_ID_NO, 10004 'TEMPLATEID', 'N' ANSWER , CONVERT(char(10), getdate(), 120) DATADATE FROM THRETRIS WHERE THRET_YN = 'Y' AND DAILYDATE = CONVERT(char(10), getdate()-1, 120) AND THRET_ID_NO NOT IN (SELECT THRET_ID_NO FROM THRETRIS WHERE DAILYDATE = CONVERT(char(10), getdate(), 120) AND THRET_YN = 'Y'))";
		Map<String, String> map = new HashMap<String, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(String.valueOf(cnt),rs.getString("THRET_ID_NO") + "|" + rs.getString("TEMPLATEID") + "|" + rs.getString("ANSWER") + "|" + rs.getString("DATADATE"));
				cnt++;
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<String, String> toETLPIDY(Connection con) {
		String sql = "SELECT CID, 10002 'TEMPLATEID', CASE WHEN (DATATYPE = 'A' OR DATATYPE = 'U') THEN 'Y' WHEN (DATATYPE = 'D' OR DATATYPE = 'E') THEN 'N' END 'ANSWER', DATADATE FROM ADMONLIST_DIFF_DAILY WHERE DATADATE = CONVERT(char(10), getdate(), 120) AND PIDNY = 'Y'";
		Map<String, String> map = new HashMap<String, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(String.valueOf(cnt),rs.getString("CID") + "|" + rs.getString("TEMPLATEID") + "|" + rs.getString("ANSWER") + "|" + rs.getString("DATADATE"));
				cnt++;
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public boolean existGray(String cId, Connection con) {
		boolean r = false;
		String sql = "SELECT THRET_ID_NO FROM THRETRIS WHERE THRET_ID_NO = ? AND THRET_ID_NO IN (SELECT CID FROM ADMONLIST_DIFF_DAILY) AND THRET_YN = 'Y' AND DAILYDATE = CONVERT(char(10), getdate(), 120)";
//		String sql = "SELECT THRET_ID_NO FROM THRETRIS WHERE THRET_ID_NO = ? AND THRET_ID_NO IN (SELECT CID FROM ADMONLIST_DIFF_DAILY) AND THRET_YN = 'Y' AND DAILYDATE = '2024-07-25'";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;		
	}	
}
