package com.ubot.kyc.db;

public class Admonlist_Diff_DailyVo {
	private String dataType;
	private String cId;
	private String name;
	private String warningDate;
	private String expireDate;
	private String issuer;
	private String dataDate;
	private String idType;
	private String pidNY;
	private String rarank;
	private String accClsmark;
	private String editTime;
	private String rmdBranch;
	private String brFlag;	
	private String blank_1;
	private String blank_2;
	private String jointNY;
	private String bankTagNY;
	private String jointId;
	private String pidId;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDataType() {
		return dataType;
	}
	
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	
	public String getcId() {
		return cId;
	}
	
	public void setcId(String cId) {
		this.cId = cId;
	}
	
	public String getWarningDate() {
		return warningDate;
	}
	
	public void setWarningDate(String warningDate) {
		this.warningDate = warningDate;
	}
	
	public String getExpireDate() {
		return expireDate;
	}
	
	public void setExpireDate(String expireDate) {
		this.expireDate = expireDate;
	}
	
	public String getIssuer() {
		return issuer;
	}
	
	public void setIssuer(String issuer) {
		this.issuer = issuer;
	}
	
	public String getDataDate() {
		return dataDate;
	}
	
	public void setDataDate(String dataDate) {
		this.dataDate = dataDate;
	}
	
	public String getIdType() {
		return idType;
	}
	
	public void setIdType(String idType) {
		this.idType = idType;
	}
	
	public String getPidNY() {
		return pidNY;
	}
	
	public void setPidNY(String pidNY) {
		this.pidNY = pidNY;
	}
	
	public String getRarank() {
		return rarank;
	}
	
	public void setRarank(String rarank) {
		this.rarank = rarank;
	}
	
	public String getAccClsmark() {
		return accClsmark;
	}
	public void setAccClsmark(String accClsmark) {
		this.accClsmark = accClsmark;
	}
	
	public String getEditTime() {
		return editTime;
	}
	
	public void setEditTime(String editTime) {
		this.editTime = editTime;
	}
	
	public String getRmdBranch() {
		return rmdBranch;
	}
	
	public void setRmdBranch(String rmdBranch) {
		this.rmdBranch = rmdBranch;
	}
	
	public String getBrFlag() {
		return brFlag;
	}
	
	public void setBrFlag(String brFlag) {
		this.brFlag = brFlag;
	}

	public String getBlank_1() {
		return blank_1;
	}

	public void setBlank_1(String blank_1) {
		this.blank_1 = blank_1;
	}

	public String getBlank_2() {
		return blank_2;
	}

	public void setBlank_2(String blank_2) {
		this.blank_2 = blank_2;
	}

	public String getJointNY() {
		return jointNY;
	}

	public void setJointNY(String jointNY) {
		this.jointNY = jointNY;
	}

	public String getBankTagNY() {
		return bankTagNY;
	}

	public void setBankTagNY(String bankTagNY) {
		this.bankTagNY = bankTagNY;
	}

	public String getJointId() {
		return jointId;
	}

	public void setJointId(String jointId) {
		this.jointId = jointId;
	}

	public String getPidId() {
		return pidId;
	}

	public void setPidId(String pidId) {
		this.pidId = pidId;
	}
}
