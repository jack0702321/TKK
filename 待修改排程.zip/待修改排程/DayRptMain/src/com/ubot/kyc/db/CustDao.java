/*KYC107005 20181109 fix dbcp usage Steven Hsieh
 * KYC108005	20190328	增加國外郵遞區號	Steven Hsieh
 * KYC108006	20190528	新增開戶日	Alex Tsai
 * KYC108009	20190422	根據vo調整	crs、obu、four、ppNum、ppDay		Alex Tsai
 *				20190520	增加RA欄位	Chia-Cheng Hsu
 *				20190621	增加出生地城市，國內外電話標記、最後編輯時間
 *							變更產品風險寫入方式						Steven Hsieh
 * KYC109004	20191101	新增職稱其他、資本額、戶籍地址里		Steven Hsieh
 */
package com.ubot.kyc.db;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class CustDao {
	
	public boolean delete(String table,Connection con) {
		boolean result = true;
		String sql = "DELETE FROM " + table;
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			int cnt = pstmt.executeUpdate(); 
			result = (cnt > 0) ? true : false;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean existCust_Y(String cId, Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM CUST_Y WHERE CID = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;		
	}
	
	public boolean exist(Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM CUST_Y";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;		
	}
	
	public boolean concatFlag_Y(Connection con) {
		boolean result = true;
//		String sql = "INSERT INTO CUST_Y SELECT A.CID,CONCAT(B.BRFLAG,C.BRFLAG,D.BRFLAG,E.BRFLAG,F.BRFLAG,G.BRFLAG,H.BRFLAG,I.BRFLAG,J.BRFLAG,K.BRFLAG,L.BRFLAG,M.BRFLAG,N.BRFLAG,O.BRFLAG,P.BRFLAG,Q.BRFLAG,R.BRFLAG)BRFLAG,A.ACCCLSDATE,'Y'OKFLAG FROM(SELECT Z.CID,MAX(Z.ACCCLSDATE)ACCCLSDATE FROM(SELECT CID,ACCCLSDATE FROM ACC01 UNION SELECT CID,ACCCLSDATE FROM ACC02 UNION SELECT CID,ACCCLSDATE FROM ACC03 UNION SELECT CID,ACCCLSDATE FROM ACC05 UNION SELECT CID,ACCCLSDATE FROM ACC06 UNION SELECT CID,ACCCLSDATE FROM ACC07 UNION SELECT CID,ACCCLSDATE FROM ACC08 UNION SELECT CID,ACCCLSDATE FROM ACC09 UNION SELECT CID,ACCCLSDATE FROM ACC11 UNION SELECT CID,ACCCLSDATE FROM ACC12 UNION SELECT CID,ACCCLSDATE FROM ACC13 UNION SELECT CID,ACCCLSDATE FROM ACC14 UNION SELECT CID,ACCCLSDATE FROM ACC15 UNION SELECT CID,ACCCLSDATE FROM ACC16 UNION SELECT CID,ACCCLSDATE FROM ACC17 UNION SELECT CID,ACCCLSDATE FROM ACC18 UNION SELECT CID,ACCCLSDATE FROM ACC19) AS Z GROUP BY Z.CID) AS A LEFT JOIN ACC01 B ON A.CID = B.CID LEFT JOIN ACC02 C ON A.CID = C.CID LEFT JOIN ACC03 D ON A.CID = D.CID LEFT JOIN ACC05 E ON A.CID = E.CID LEFT JOIN ACC06 F ON A.CID = F.CID LEFT JOIN ACC07 G ON A.CID = G.CID LEFT JOIN ACC08 H ON A.CID = H.CID LEFT JOIN ACC09 I ON A.CID = I.CID LEFT JOIN ACC11 J ON A.CID = J.CID LEFT JOIN ACC12 K ON A.CID = K.CID LEFT JOIN ACC13 L ON A.CID = L.CID LEFT JOIN ACC14 M ON A.CID = M.CID LEFT JOIN ACC15 N ON A.CID = N.CID LEFT JOIN ACC16 O ON A.CID = O.CID LEFT JOIN ACC17 P ON A.CID = P.CID LEFT JOIN ACC18 Q ON A.CID = Q.CID LEFT JOIN ACC19 R ON A.CID = R.CID";
//		String sql = "INSERT INTO CUST_Y SELECT A.CID,CONCAT(B.BRFLAG,C.BRFLAG,D.BRFLAG,E.BRFLAG,F.BRFLAG,G.BRFLAG,H.BRFLAG,I.BRFLAG,J.BRFLAG,K.BRFLAG,L.BRFLAG,M.BRFLAG,N.BRFLAG,O.BRFLAG,P.BRFLAG,Q.BRFLAG,R.BRFLAG,S.BRFLAG)BRFLAG,A.ACCCLSDATE,'Y'OKFLAG,CONCAT(R.BRRFLAG,S.BRRFLAG) BRRFLAG FROM(SELECT Z.CID,MAX(Z.ACCCLSDATE)ACCCLSDATE FROM(SELECT CID,ACCCLSDATE FROM ACC01 UNION SELECT CID,ACCCLSDATE FROM ACC02 UNION SELECT CID,ACCCLSDATE FROM ACC03 UNION SELECT CID,ACCCLSDATE FROM ACC05 UNION SELECT CID,ACCCLSDATE FROM ACC06 UNION SELECT CID,ACCCLSDATE FROM ACC07 UNION SELECT CID,ACCCLSDATE FROM ACC08 UNION SELECT CID,ACCCLSDATE FROM ACC09 UNION SELECT CID,ACCCLSDATE FROM ACC11 UNION SELECT CID,ACCCLSDATE FROM ACC12 UNION SELECT CID,ACCCLSDATE FROM ACC13 UNION SELECT CID,ACCCLSDATE FROM ACC14 UNION SELECT CID,ACCCLSDATE FROM ACC15 UNION SELECT CID,ACCCLSDATE FROM ACC16 UNION SELECT CID,ACCCLSDATE FROM ACC17 UNION SELECT CID,ACCCLSDATE FROM ACC18 UNION SELECT CID,ACCCLSDATE FROM ACC19R02 UNION SELECT CID,ACCCLSDATE FROM ACC19R03) AS Z GROUP BY Z.CID) AS A LEFT JOIN ACC01 B ON A.CID = B.CID LEFT JOIN ACC02 C ON A.CID = C.CID LEFT JOIN ACC03 D ON A.CID = D.CID LEFT JOIN ACC05 E ON A.CID = E.CID LEFT JOIN ACC06 F ON A.CID = F.CID LEFT JOIN ACC07 G ON A.CID = G.CID LEFT JOIN ACC08 H ON A.CID = H.CID LEFT JOIN ACC09 I ON A.CID = I.CID LEFT JOIN ACC11 J ON A.CID = J.CID LEFT JOIN ACC12 K ON A.CID = K.CID LEFT JOIN ACC13 L ON A.CID = L.CID LEFT JOIN ACC14 M ON A.CID = M.CID LEFT JOIN ACC15 N ON A.CID = N.CID LEFT JOIN ACC16 O ON A.CID = O.CID LEFT JOIN ACC17 P ON A.CID = P.CID LEFT JOIN ACC18 Q ON A.CID = Q.CID LEFT JOIN ACC19R02 R ON A.CID = R.CID LEFT JOIN ACC19R03 S ON A.CID = S.CID";
//		String sql = "INSERT INTO CUST_Y SELECT A.CID,CONCAT(B.BRFLAG,C.BRFLAG,D.BRFLAG,E.BRFLAG,F.BRFLAG,G.BRFLAG,H.BRFLAG,I.BRFLAG,J.BRFLAG,K.BRFLAG,L.BRFLAG,M.BRFLAG,N.BRFLAG,O.BRFLAG,P.BRFLAG,Q.BRFLAG,R.BRFLAG,S.BRFLAG,T.BRFLAG,U.BRFLAG,V.BRFLAG)BRFLAG,A.ACCCLSDATE,'Y'OKFLAG,CONCAT(R.BRRFLAG,S.BRRFLAG,T.BRRFLAG) BRRFLAG FROM(SELECT Z.CID,MAX(Z.ACCCLSDATE)ACCCLSDATE FROM(SELECT CID,ACCCLSDATE FROM ACC01 UNION SELECT CID,ACCCLSDATE FROM ACC02 UNION SELECT CID,ACCCLSDATE FROM ACC03 UNION SELECT CID,ACCCLSDATE FROM ACC05 UNION SELECT CID,ACCCLSDATE FROM ACC06 UNION SELECT CID,ACCCLSDATE FROM ACC07 UNION SELECT CID,ACCCLSDATE FROM ACC08 UNION SELECT CID,ACCCLSDATE FROM ACC09 UNION SELECT CID,ACCCLSDATE FROM ACC11 UNION SELECT CID,ACCCLSDATE FROM ACC12 UNION SELECT CID,ACCCLSDATE FROM ACC13 UNION SELECT CID,ACCCLSDATE FROM ACC14 UNION SELECT CID,ACCCLSDATE FROM ACC15 UNION SELECT CID,ACCCLSDATE FROM ACC16 UNION SELECT CID,ACCCLSDATE FROM ACC17 UNION SELECT CID,ACCCLSDATE FROM ACC18 UNION SELECT CID,ACCCLSDATE FROM ACC19R02 UNION SELECT CID,ACCCLSDATE FROM ACC19R03 UNION SELECT CID,ACCCLSDATE FROM ACC14M01 UNION SELECT CID,ACCCLSDATE FROM ACC20 UNION SELECT CID,ACCCLSDATE FROM ACC21) AS Z GROUP BY Z.CID) AS A LEFT JOIN ACC01 B ON A.CID = B.CID LEFT JOIN ACC02 C ON A.CID = C.CID LEFT JOIN ACC03 D ON A.CID = D.CID LEFT JOIN ACC05 E ON A.CID = E.CID LEFT JOIN ACC06 F ON A.CID = F.CID LEFT JOIN ACC07 G ON A.CID = G.CID LEFT JOIN ACC08 H ON A.CID = H.CID LEFT JOIN ACC09 I ON A.CID = I.CID LEFT JOIN ACC11 J ON A.CID = J.CID LEFT JOIN ACC12 K ON A.CID = K.CID LEFT JOIN ACC13 L ON A.CID = L.CID LEFT JOIN ACC14 M ON A.CID = M.CID LEFT JOIN ACC15 N ON A.CID = N.CID LEFT JOIN ACC16 O ON A.CID = O.CID LEFT JOIN ACC17 P ON A.CID = P.CID LEFT JOIN ACC18 Q ON A.CID = Q.CID LEFT JOIN ACC19R02 R ON A.CID = R.CID LEFT JOIN ACC19R03 S ON A.CID = S.CID LEFT JOIN ACC14M01 T ON A.CID = T.CID LEFT JOIN ACC20 U ON A.CID = U.CID LEFT JOIN ACC21 V ON A.CID = V.CID";
		String sql = "INSERT INTO CUST_Y SELECT A.CID,CONCAT(B.BRFLAG,C.BRFLAG,D.BRFLAG,E.BRFLAG,F.BRFLAG,G.BRFLAG,H.BRFLAG,I.BRFLAG,J.BRFLAG,K.BRFLAG,L.BRFLAG,M.BRFLAG,N.BRFLAG,O.BRFLAG,P.BRFLAG,Q.BRFLAG,R.BRFLAG,T.BRFLAG,U.BRFLAG,V.BRFLAG,W.BRFLAG,X.BRFLAG)BRFLAG,A.ACCCLSDATE,'Y'OKFLAG,CONCAT(R.BRRFLAG,T.BRRFLAG) BRRFLAG FROM(SELECT Z.CID,MAX(Z.ACCCLSDATE)ACCCLSDATE FROM(SELECT CID,ACCCLSDATE FROM ACC01 UNION SELECT CID,ACCCLSDATE FROM ACC02 UNION SELECT CID,ACCCLSDATE FROM ACC03 UNION SELECT CID,ACCCLSDATE FROM ACC05 UNION SELECT CID,ACCCLSDATE FROM ACC06 UNION SELECT CID,ACCCLSDATE FROM ACC07 UNION SELECT CID,ACCCLSDATE FROM ACC08 UNION SELECT CID,ACCCLSDATE FROM ACC09 UNION SELECT CID,ACCCLSDATE FROM ACC11 UNION SELECT CID,ACCCLSDATE FROM ACC12 UNION SELECT CID,ACCCLSDATE FROM ACC13 UNION SELECT CID,ACCCLSDATE FROM ACC14 UNION SELECT CID,ACCCLSDATE FROM ACC15 UNION SELECT CID,ACCCLSDATE FROM ACC16 UNION SELECT CID,ACCCLSDATE FROM ACC17 UNION SELECT CID,ACCCLSDATE FROM ACC18 UNION SELECT CID,ACCCLSDATE FROM ACC19R02 UNION SELECT CID,ACCCLSDATE FROM ACC14M01 UNION SELECT CID,ACCCLSDATE FROM ACC20 UNION SELECT CID,ACCCLSDATE FROM ACC21 UNION SELECT CID,ACCCLSDATE FROM ACC22 UNION SELECT CID,ACCCLSDATE FROM ACC23) AS Z GROUP BY Z.CID) AS A LEFT JOIN ACC01 B ON A.CID = B.CID LEFT JOIN ACC02 C ON A.CID = C.CID LEFT JOIN ACC03 D ON A.CID = D.CID LEFT JOIN ACC05 E ON A.CID = E.CID LEFT JOIN ACC06 F ON A.CID = F.CID LEFT JOIN ACC07 G ON A.CID = G.CID LEFT JOIN ACC08 H ON A.CID = H.CID LEFT JOIN ACC09 I ON A.CID = I.CID LEFT JOIN ACC11 J ON A.CID = J.CID LEFT JOIN ACC12 K ON A.CID = K.CID LEFT JOIN ACC13 L ON A.CID = L.CID LEFT JOIN ACC14 M ON A.CID = M.CID LEFT JOIN ACC15 N ON A.CID = N.CID LEFT JOIN ACC16 O ON A.CID = O.CID LEFT JOIN ACC17 P ON A.CID = P.CID LEFT JOIN ACC18 Q ON A.CID = Q.CID LEFT JOIN ACC19R02 R ON A.CID = R.CID LEFT JOIN ACC14M01 T ON A.CID = T.CID LEFT JOIN ACC20 U ON A.CID = U.CID LEFT JOIN ACC21 V ON A.CID = V.CID LEFT JOIN ACC22 W ON A.CID = W.CID LEFT JOIN ACC23 X ON A.CID = X.CID";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			int cnt = pstmt.executeUpdate();
			result = (cnt > 0) ? true : false;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean concatFlag_F(Connection con) {
		boolean result = true;
//		String sql = "INSERT INTO CUST_Y SELECT A.CID,CONCAT(B.BRFLAG,C.BRFLAG,D.BRFLAG,E.BRFLAG,F.BRFLAG,G.BRFLAG,H.BRFLAG,I.BRFLAG,J.BRFLAG,K.BRFLAG,L.BRFLAG,M.BRFLAG,N.BRFLAG,O.BRFLAG,P.BRFLAG,Q.BRFLAG,R.BRFLAG)BRFLAG,A.ACCCLSDATE,'F'OKFLAG FROM(SELECT Z.CID,MAX(Z.ACCCLSDATE)ACCCLSDATE FROM(SELECT CID,ACCCLSDATE FROM ACC01 UNION SELECT CID,ACCCLSDATE FROM ACC02 UNION SELECT CID,ACCCLSDATE FROM ACC03 UNION SELECT CID,ACCCLSDATE FROM ACC05 UNION SELECT CID,ACCCLSDATE FROM ACC06 UNION SELECT CID,ACCCLSDATE FROM ACC07 UNION SELECT CID,ACCCLSDATE FROM ACC08 UNION SELECT CID,ACCCLSDATE FROM ACC09 UNION SELECT CID,ACCCLSDATE FROM ACC11 UNION SELECT CID,ACCCLSDATE FROM ACC12 UNION SELECT CID,ACCCLSDATE FROM ACC13 UNION SELECT CID,ACCCLSDATE FROM ACC14 UNION SELECT CID,ACCCLSDATE FROM ACC15 UNION SELECT CID,ACCCLSDATE FROM ACC16 UNION SELECT CID,ACCCLSDATE FROM ACC17 UNION SELECT CID,ACCCLSDATE FROM ACC18 UNION SELECT CID,ACCCLSDATE FROM ACC19) AS Z GROUP BY Z.CID) AS A LEFT JOIN ACC01 B ON A.CID = B.CID LEFT JOIN ACC02 C ON A.CID = C.CID LEFT JOIN ACC03 D ON A.CID = D.CID LEFT JOIN ACC05 E ON A.CID = E.CID LEFT JOIN ACC06 F ON A.CID = F.CID LEFT JOIN ACC07 G ON A.CID = G.CID LEFT JOIN ACC08 H ON A.CID = H.CID LEFT JOIN ACC09 I ON A.CID = I.CID LEFT JOIN ACC11 J ON A.CID = J.CID LEFT JOIN ACC12 K ON A.CID = K.CID LEFT JOIN ACC13 L ON A.CID = L.CID LEFT JOIN ACC14 M ON A.CID = M.CID LEFT JOIN ACC15 N ON A.CID = N.CID LEFT JOIN ACC16 O ON A.CID = O.CID LEFT JOIN ACC17 P ON A.CID = P.CID LEFT JOIN ACC18 Q ON A.CID = Q.CID LEFT JOIN ACC19 R ON A.CID = R.CID";
//		String sql = "INSERT INTO CUST_Y SELECT A.CID,CONCAT(B.BRFLAG,C.BRFLAG,D.BRFLAG,E.BRFLAG,F.BRFLAG,G.BRFLAG,H.BRFLAG,I.BRFLAG,J.BRFLAG,K.BRFLAG,L.BRFLAG,M.BRFLAG,N.BRFLAG,O.BRFLAG,P.BRFLAG,Q.BRFLAG,R.BRFLAG,S.BRFLAG)BRFLAG,A.ACCCLSDATE,'F'OKFLAG,CONCAT(R.BRRFLAG,S.BRRFLAG) BRRFLAG FROM(SELECT Z.CID,MAX(Z.ACCCLSDATE)ACCCLSDATE FROM(SELECT CID,ACCCLSDATE FROM ACC01 UNION SELECT CID,ACCCLSDATE FROM ACC02 UNION SELECT CID,ACCCLSDATE FROM ACC03 UNION SELECT CID,ACCCLSDATE FROM ACC05 UNION SELECT CID,ACCCLSDATE FROM ACC06 UNION SELECT CID,ACCCLSDATE FROM ACC07 UNION SELECT CID,ACCCLSDATE FROM ACC08 UNION SELECT CID,ACCCLSDATE FROM ACC09 UNION SELECT CID,ACCCLSDATE FROM ACC11 UNION SELECT CID,ACCCLSDATE FROM ACC12 UNION SELECT CID,ACCCLSDATE FROM ACC13 UNION SELECT CID,ACCCLSDATE FROM ACC14 UNION SELECT CID,ACCCLSDATE FROM ACC15 UNION SELECT CID,ACCCLSDATE FROM ACC16 UNION SELECT CID,ACCCLSDATE FROM ACC17 UNION SELECT CID,ACCCLSDATE FROM ACC18 UNION SELECT CID,ACCCLSDATE FROM ACC19R02 UNION SELECT CID,ACCCLSDATE FROM ACC19R03) AS Z GROUP BY Z.CID) AS A LEFT JOIN ACC01 B ON A.CID = B.CID LEFT JOIN ACC02 C ON A.CID = C.CID LEFT JOIN ACC03 D ON A.CID = D.CID LEFT JOIN ACC05 E ON A.CID = E.CID LEFT JOIN ACC06 F ON A.CID = F.CID LEFT JOIN ACC07 G ON A.CID = G.CID LEFT JOIN ACC08 H ON A.CID = H.CID LEFT JOIN ACC09 I ON A.CID = I.CID LEFT JOIN ACC11 J ON A.CID = J.CID LEFT JOIN ACC12 K ON A.CID = K.CID LEFT JOIN ACC13 L ON A.CID = L.CID LEFT JOIN ACC14 M ON A.CID = M.CID LEFT JOIN ACC15 N ON A.CID = N.CID LEFT JOIN ACC16 O ON A.CID = O.CID LEFT JOIN ACC17 P ON A.CID = P.CID LEFT JOIN ACC18 Q ON A.CID = Q.CID LEFT JOIN ACC19R02 R ON A.CID = R.CID LEFT JOIN ACC19R03 S ON A.CID = S.CID";
//		String sql = "INSERT INTO CUST_Y SELECT A.CID,CONCAT(B.BRFLAG,C.BRFLAG,D.BRFLAG,E.BRFLAG,F.BRFLAG,G.BRFLAG,H.BRFLAG,I.BRFLAG,J.BRFLAG,K.BRFLAG,L.BRFLAG,M.BRFLAG,N.BRFLAG,O.BRFLAG,P.BRFLAG,Q.BRFLAG,R.BRFLAG,S.BRFLAG,T.BRFLAG,U.BRFLAG,V.BRFLAG)BRFLAG,A.ACCCLSDATE,'Y'OKFLAG,CONCAT(R.BRRFLAG,S.BRRFLAG,T.BRRFLAG) BRRFLAG FROM(SELECT Z.CID,MAX(Z.ACCCLSDATE)ACCCLSDATE FROM(SELECT CID,ACCCLSDATE FROM ACC01 UNION SELECT CID,ACCCLSDATE FROM ACC02 UNION SELECT CID,ACCCLSDATE FROM ACC03 UNION SELECT CID,ACCCLSDATE FROM ACC05 UNION SELECT CID,ACCCLSDATE FROM ACC06 UNION SELECT CID,ACCCLSDATE FROM ACC07 UNION SELECT CID,ACCCLSDATE FROM ACC08 UNION SELECT CID,ACCCLSDATE FROM ACC09 UNION SELECT CID,ACCCLSDATE FROM ACC11 UNION SELECT CID,ACCCLSDATE FROM ACC12 UNION SELECT CID,ACCCLSDATE FROM ACC13 UNION SELECT CID,ACCCLSDATE FROM ACC14 UNION SELECT CID,ACCCLSDATE FROM ACC15 UNION SELECT CID,ACCCLSDATE FROM ACC16 UNION SELECT CID,ACCCLSDATE FROM ACC17 UNION SELECT CID,ACCCLSDATE FROM ACC18 UNION SELECT CID,ACCCLSDATE FROM ACC19R02 UNION SELECT CID,ACCCLSDATE FROM ACC19R03 UNION SELECT CID,ACCCLSDATE FROM ACC14M01 UNION SELECT CID,ACCCLSDATE FROM ACC20 UNION SELECT CID,ACCCLSDATE FROM ACC21) AS Z GROUP BY Z.CID) AS A LEFT JOIN ACC01 B ON A.CID = B.CID LEFT JOIN ACC02 C ON A.CID = C.CID LEFT JOIN ACC03 D ON A.CID = D.CID LEFT JOIN ACC05 E ON A.CID = E.CID LEFT JOIN ACC06 F ON A.CID = F.CID LEFT JOIN ACC07 G ON A.CID = G.CID LEFT JOIN ACC08 H ON A.CID = H.CID LEFT JOIN ACC09 I ON A.CID = I.CID LEFT JOIN ACC11 J ON A.CID = J.CID LEFT JOIN ACC12 K ON A.CID = K.CID LEFT JOIN ACC13 L ON A.CID = L.CID LEFT JOIN ACC14 M ON A.CID = M.CID LEFT JOIN ACC15 N ON A.CID = N.CID LEFT JOIN ACC16 O ON A.CID = O.CID LEFT JOIN ACC17 P ON A.CID = P.CID LEFT JOIN ACC18 Q ON A.CID = Q.CID LEFT JOIN ACC19R02 R ON A.CID = R.CID LEFT JOIN ACC19R03 S ON A.CID = S.CID LEFT JOIN ACC14M01 T ON A.CID = T.CID LEFT JOIN ACC20 U ON A.CID = U.CID LEFT JOIN ACC21 V ON A.CID = V.CID";
		String sql = "INSERT INTO CUST_Y SELECT A.CID,CONCAT(B.BRFLAG,C.BRFLAG,D.BRFLAG,E.BRFLAG,F.BRFLAG,G.BRFLAG,H.BRFLAG,I.BRFLAG,J.BRFLAG,K.BRFLAG,L.BRFLAG,M.BRFLAG,N.BRFLAG,O.BRFLAG,P.BRFLAG,Q.BRFLAG,R.BRFLAG,T.BRFLAG,U.BRFLAG,V.BRFLAG,W.BRFLAG,X.BRFLAG)BRFLAG,A.ACCCLSDATE,'Y'OKFLAG,CONCAT(R.BRRFLAG,T.BRRFLAG) BRRFLAG FROM(SELECT Z.CID,MAX(Z.ACCCLSDATE)ACCCLSDATE FROM(SELECT CID,ACCCLSDATE FROM ACC01 UNION SELECT CID,ACCCLSDATE FROM ACC02 UNION SELECT CID,ACCCLSDATE FROM ACC03 UNION SELECT CID,ACCCLSDATE FROM ACC05 UNION SELECT CID,ACCCLSDATE FROM ACC06 UNION SELECT CID,ACCCLSDATE FROM ACC07 UNION SELECT CID,ACCCLSDATE FROM ACC08 UNION SELECT CID,ACCCLSDATE FROM ACC09 UNION SELECT CID,ACCCLSDATE FROM ACC11 UNION SELECT CID,ACCCLSDATE FROM ACC12 UNION SELECT CID,ACCCLSDATE FROM ACC13 UNION SELECT CID,ACCCLSDATE FROM ACC14 UNION SELECT CID,ACCCLSDATE FROM ACC15 UNION SELECT CID,ACCCLSDATE FROM ACC16 UNION SELECT CID,ACCCLSDATE FROM ACC17 UNION SELECT CID,ACCCLSDATE FROM ACC18 UNION SELECT CID,ACCCLSDATE FROM ACC19R02 UNION SELECT CID,ACCCLSDATE FROM ACC14M01 UNION SELECT CID,ACCCLSDATE FROM ACC20 UNION SELECT CID,ACCCLSDATE FROM ACC21 UNION SELECT CID,ACCCLSDATE FROM ACC22 UNION SELECT CID,ACCCLSDATE FROM ACC23) AS Z GROUP BY Z.CID) AS A LEFT JOIN ACC01 B ON A.CID = B.CID LEFT JOIN ACC02 C ON A.CID = C.CID LEFT JOIN ACC03 D ON A.CID = D.CID LEFT JOIN ACC05 E ON A.CID = E.CID LEFT JOIN ACC06 F ON A.CID = F.CID LEFT JOIN ACC07 G ON A.CID = G.CID LEFT JOIN ACC08 H ON A.CID = H.CID LEFT JOIN ACC09 I ON A.CID = I.CID LEFT JOIN ACC11 J ON A.CID = J.CID LEFT JOIN ACC12 K ON A.CID = K.CID LEFT JOIN ACC13 L ON A.CID = L.CID LEFT JOIN ACC14 M ON A.CID = M.CID LEFT JOIN ACC15 N ON A.CID = N.CID LEFT JOIN ACC16 O ON A.CID = O.CID LEFT JOIN ACC17 P ON A.CID = P.CID LEFT JOIN ACC18 Q ON A.CID = Q.CID LEFT JOIN ACC19R02 R ON A.CID = R.CID LEFT JOIN ACC14M01 T ON A.CID = T.CID LEFT JOIN ACC20 U ON A.CID = U.CID LEFT JOIN ACC21 V ON A.CID = V.CID LEFT JOIN ACC22 W ON A.CID = W.CID LEFT JOIN ACC22 X ON A.CID = X.CID";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			int cnt = pstmt.executeUpdate();
			result = (cnt > 0) ? true : false;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public CustVo findById(String cId, Connection con) {
		String sql = "SELECT CID, IDTYPE, BRFLAG, EDITTIME, ACCCLSMARK, ACCCLSDATE, RKYCTIME, UID, BRANCH, RDDLCONN FROM CUST WHERE CID = ?";
		CustVo cVo = new CustVo();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				cVo.setCId(rs.getString("CID"));
				cVo.setIdType(rs.getString("IDTYPE"));
				cVo.setBRFlag(rs.getString("BRFLAG"));
				cVo.setEditTime(rs.getString("EDITTIME"));
				cVo.setAccClsMark(rs.getString("ACCCLSMARK"));
				cVo.setAccClsDate(rs.getString("ACCCLSDATE"));
				cVo.setrKYCTime(rs.getString("RKYCTIME"));
				cVo.setUId(rs.getString("UID"));
				cVo.setBranch(rs.getString("BRANCH"));
				cVo.setrDDLConn(rs.getString("RDDLCONN"));
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return cVo;		
	}
	
	public boolean writeAcc(String cId, String date,String flag, String table, Connection con) throws SQLException {
		boolean res = true;
		if(selectAcc(cId, table, con)) {
			res = false;
		}else {
			res = insertAcc(cId, date, flag, table, con);
		}		
		return res;
	}
	
	public boolean writeAcc(String cId, String date, String flag, String brrFlag, String table, Connection con) throws SQLException {
		boolean res = true;
		if(selectAcc(cId, table, con)) {
			res = false;
		}else {
			res = insertAcc(cId, date, flag, brrFlag, table, con);
		}		
		return res;
	}
	
	public boolean insertAcc(String cId, String date,String flag, String table, Connection con) throws SQLException {
		boolean result = true;
		String sql = "INSERT INTO " + table + "(CID,ACCCLSDATE,BRFLAG,OKFLAG)VALUES(?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		
		ps.setString(1, cId);
		ps.setString(2, date);
		ps.setString(3, flag);
		ps.setString(4, "Y");
		
		int cnt = ps.executeUpdate();
		result = (cnt > 0) ? true : false;
		ps.close();
		return result;
	}
	
	public boolean insertAcc(String cId, String date,String flag, String brrFlag, String table, Connection con) throws SQLException {
		boolean result = true;
		String sql = "INSERT INTO " + table + "(CID,ACCCLSDATE,BRFLAG,BRRFLAG,OKFLAG)VALUES(?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		
		ps.setString(1, cId);
		ps.setString(2, date);
		ps.setString(3, flag);
		ps.setString(4, brrFlag);
		ps.setString(5, "Y");
		
		int cnt = ps.executeUpdate();
		result = (cnt > 0) ? true : false;
		ps.close();
		return result;
	}
	
	public Map<String, String> custMap(Connection con) {
		String sql = "SELECT CID FROM CUST";
		Map<String, String> map = new HashMap<String, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(rs.getString("CID"),"");
			}
		} catch (SQLException sqlE) {			
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public boolean selectAcc(String cId, String table, Connection con) throws SQLException {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM " + table + " WHERE CID = ?";
		PreparedStatement pstmt = con.prepareStatement(sql);		
		pstmt.setString(1, cId);		
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			r = true;
		}
		pstmt.close();
		return r;
	}
	
	public List<String> noCId(Connection con) {
		String sql = "SELECT CID,ACCCLSDATE,BRFLAG FROM CUST_Y WHERE (SELECT COUNT(1) AS NUM FROM CUST WHERE CUST.CID = CUST_Y.CID) = 0";
		List<String> cId = new ArrayList<String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				cId.add(rs.getString("CID") + "|" + rs.getString("ACCCLSDATE") + "|" + chgFlag(rs.getString("BRFLAG")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return cId;	
	}
	
	private String chgFlag(String flag) {
		for(int i=flag.length()-2;i>0;i=i-2) {
			flag = flag.substring(0,i)+","+flag.substring(i);
		}
		return flag;
	}
	
	/*public boolean noCId(String cId,Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM CUST_Y WHERE ((SELECT COUNT(1) AS NUM FROM CUST WHERE CUST.CID = CUST_Y.CID) = 0) AND (CID = ?)";
		PreparedStatement pstmt = null;
		ResultSet rs = null;		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}			
		}
		return r;
	}*/
	
	public boolean existDate(String cId, String date, Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM CUST WHERE EDITTIME >= ? AND CID = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, date);
			pstmt.setString(2, cId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;
	}
	
	public boolean existHCust(String cId, Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM H_CUST WHERE CID = ? AND RDDLCONN != ''";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;
	}
	
	/*public boolean existDate(String cId,Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM CUST INNER JOIN CUST_Y ON CUST.EDITTIME > CUST_Y.ACCCLSDATE AND CUST.CID = CUST_Y.CID WHERE CUST.CID = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}			
		}
		return r;
	}*/
	
	public boolean existStatus(String cId,Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM CUST INNER JOIN FLOW ON (USTATUS LIKE '1%' OR USTATUS LIKE '2%' OR USTATUS LIKE '3%') AND CUST.CID = FLOW.CID WHERE CUST.CID = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}			
		}
		return r;
	}	
	
	public boolean existAcc(String cId,Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM CUST INNER JOIN CUST_Y ON CUST.CID = CUST_Y.CID WHERE CUST.CID = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}			
		}
		return r;
	}
	
	public boolean updateAcc(CustVo vo, String flag, String code, Connection con) {
		boolean result = true;
		PreparedStatement pstmt = null;
		String sql = "UPDATE CUST SET BRFLAG=?, ACCCLSDATE=?, ACCCLSMARK=?, BATCHCODE=? WHERE CID=?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, flag);
			pstmt.setString(2,vo.getAccClsDate());
			pstmt.setString(3, vo.getAccClsMark());
			pstmt.setString(4, code);
			pstmt.setString(5, vo.getCId());

			int cnt = pstmt.executeUpdate();
			result = (cnt > 0) ? true : false;
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean updateMark_F(CustVo vo, Connection con) {
		boolean result = true;
		PreparedStatement pstmt = null;
		String sql = "UPDATE CUST SET ACCCLSMARK=?,ACCCLSDATE=? WHERE CID=?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, vo.getAccClsMark());
			pstmt.setString(2, vo.getAccClsDate());
			pstmt.setString(3, vo.getCId());

			int cnt = pstmt.executeUpdate();
			result = (cnt > 0) ? true : false;
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean updateMartT(String cId, Connection con) {
		boolean result = true;
		PreparedStatement pstmt = null;
		String sql = "UPDATE CUST SET BRFLAG=?, ACCCLSMARK=? WHERE CID = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "");
			pstmt.setString(2, "1");
			pstmt.setString(3, cId);
			
			int cnt = pstmt.executeUpdate();
			result = (cnt > 0) ? true : false;
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean updateMarkT(String cId, String now, String code, Connection con) {
		boolean result = true;
		PreparedStatement pstmt = null;
		String sql = "UPDATE CUST SET BRFLAG=?, ACCCLSMARK=?, ACCCLSDATE=?, BATCHCODE=? WHERE CID=?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "");
			pstmt.setString(2, "1");
			pstmt.setString(3, now);
			pstmt.setString(4, code);
			pstmt.setString(5, cId);
			
			int cnt = pstmt.executeUpdate();
			result = (cnt > 0) ? true : false;
		} catch (SQLException sqlE) {			
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean deleteMarkT(Connection con) {
		boolean result = true;	// CB:CUSTBR	CT:CUST
		String sql = "DELETE CB FROM CUSTBR CB LEFT JOIN CUST CT ON CB.CID = CT.CID WHERE CT.BRFLAG = ?";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "");
			int cnt = pstmt.executeUpdate(); 
			result = (cnt > 0) ? true : false;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public Map<String, String> markListO(Connection con) {
		String sql = "SELECT CID FROM CUST WHERE ACCCLSMARK = '0'";
		Map<String, String> map = new HashMap<String, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(rs.getString("CID"),"");
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public Map<String, String> markListC(Connection con) {
		String sql = "SELECT CID FROM CUST WHERE ACCCLSMARK = '1'";
		Map<String, String> map = new HashMap<String, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(rs.getString("CID"),"");
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public String getTime(String custNo, Connection con) {
		String sql = "SELECT RDATETIME FROM [ICTI] WHERE CID=? AND SENDDATA like '%K0000%'";
		String str = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, custNo);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				str = rs.getString("RDATETIME");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return str;
	}
	
	public Map<String, String> getList(String custNo, String sMonth, String dMonth, Connection con) {
		String sql = "SELECT CID,CASE UID WHEN '1049999' THEN '客服' WHEN '1049998' THEN '個網' WHEN '1049997' THEN '數存' WHEN '1049996' THEN 'APP' ELSE UID END UID,RDATETIME FROM [ICTI] WHERE CID=? AND RDATETIME < '" + dMonth + "' AND RDATETIME >= '" + sMonth + "' AND SENDDATA like '%K0000%' ORDER BY UID,RDATETIME";
		Map<String, String> map = new HashMap<String, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			pstmt.setString(1, custNo);
			while (rs.next()) {
				map.put(rs.getString("CID"), rs.getString("UID") + "|" + rs.getString("RDATETIME"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return map;
	}
	
	public boolean existICTI(String cId, Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM [ICTI] WHERE CID = ? AND SENDDATA like '%K0000%'";
		PreparedStatement pstmt = null;
		ResultSet rs = null;		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;		
	}
	
	public boolean existCust(String cId, Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM CUST WHERE CID = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;	
	}
	
	public boolean existTrue(String cId, Connection con) {
		boolean r = false;
//		String sql = "SELECT EDITTIME FROM CUST WHERE EDITTIME >= '2021-06-01 00:00:00' AND CID = ?";
		String sql = "SELECT CID FROM CUST WHERE CID = ?";
		PreparedStatement pstmt = null;	
		ResultSet rs = null;		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;	
	}
	
	public boolean selectACC(String cId, Connection con) {
		boolean r = false;
		String sql = "SELECT CID FROM CUST WHERE ACCCLSMARK = '0' AND CID = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;	
	}
	
	public String getCount(String accStr, Connection con) {
		String sql = "SELECT COUNT(CID) CUNT FROM " + accStr;
		String str = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				str = rs.getString("CUNT");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return str;
	}

	public boolean insertCDDY(String cId, Connection con) {
		boolean result = true;
		String sql = "INSERT INTO RPT_CDDY (CID) VALUES (?)";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			int cnt = pstmt.executeUpdate();
			result = (cnt > 0) ? true : false;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public boolean insertCDDN(String cId, Connection con) {
		boolean result = true;
		String sql = "INSERT INTO RPT_CDDN (CID) VALUES (?)";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			int cnt = pstmt.executeUpdate();
			result = (cnt > 0) ? true : false;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public String getRank(String cId, String date, Connection con) {
		String sql = "SELECT RARANK,RKYCTIME FROM CUST WHERE CID = ? AND SUBSTRING(REPLACE(RKYCTIME,'-',''),0,9) <= ?";
		String str = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			pstmt.setString(2, date);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				str = rs.getString("RARANK") + "|" + rs.getString("RKYCTIME");
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return str;
	}
	
	public String getA1(String cId, String date, Connection con) {
//		String sql = "SELECT TOP 1 RARANK,RKYCTIME FROM H_CUST WHERE CID = ? AND SUBSTRING(REPLACE(RKYCTIME,'-',''),0,9) <= ? ORDER BY RKYCTIME DESC";
		String sql = "SELECT BIRTHD, CASE BIRTHP WHEN '1' THEN 'TW' WHEN '2' THEN BIRTHPO END BIRTHP, CASE MAILADDFLAG WHEN '1' THEN MAILCITY + MAILAREA + MAILSTREET + (CASE MAILLANE WHEN '' THEN '' ELSE MAILLANE + '巷' END) + (CASE MAILALY WHEN '' THEN '' ELSE MAILLANE + '弄' END) + (CASE MAILOF WHEN '' THEN MAILNUM + '號' ELSE MAILNUM + '-' + MAILOF + '號' END) + (CASE MAILFLR WHEN '' THEN '' ELSE MAILFLR + '樓' END) + MAILETC WHEN '2' THEN MAILADD WHEN '3' THEN (CASE HOMEADDFLAG WHEN '1' THEN HOMECITY + HOMEAREA + HOMEVIL + HOMESTREET + (CASE HOMELANE WHEN '' THEN '' ELSE HOMELANE + '巷' END) + (CASE HOMEALY WHEN '' THEN '' ELSE HOMELANE + '弄' END) + (CASE HOMEOF WHEN '' THEN HOMENUM + '號' ELSE HOMENUM + '-' + HOMEOF + '號' END) + (CASE HOMEFLR WHEN '' THEN '' ELSE HOMEFLR + '樓' END) + HOMEETC WHEN '2' THEN HOMEADD END) END MAILADD, CASE LIVEADDFLAG WHEN '1' THEN LIVECITY + LIVEAREA + LIVESTREET + (CASE LIVELANE WHEN '' THEN '' ELSE LIVELANE + '巷' END) + (CASE LIVEALY WHEN '' THEN '' ELSE LIVELANE + '弄' END) + (CASE LIVEOF WHEN '' THEN LIVENUM + '號' ELSE LIVENUM + '-' + LIVEOF + '號' END) + (CASE LIVEFLR WHEN '' THEN '' ELSE LIVEFLR + '樓' END) + LIVEETC WHEN '2' THEN LIVEADD WHEN '3' THEN (CASE HOMEADDFLAG WHEN '1' THEN HOMECITY + HOMEAREA + HOMEVIL + HOMESTREET + (CASE HOMELANE WHEN '' THEN '' ELSE HOMELANE + '巷' END) + (CASE HOMEALY WHEN '' THEN '' ELSE HOMELANE + '弄' END) + (CASE HOMEOF WHEN '' THEN HOMENUM + '號' ELSE HOMENUM + '-' + HOMEOF + '號' END) + (CASE HOMEFLR WHEN '' THEN '' ELSE HOMEFLR + '樓' END) + HOMEETC WHEN '2' THEN HOMEADD END) WHEN '4' THEN (CASE MAILADDFLAG WHEN '1' THEN MAILCITY + MAILAREA + MAILSTREET + (CASE MAILLANE WHEN '' THEN '' ELSE MAILLANE + '巷' END) + (CASE MAILALY WHEN '' THEN '' ELSE MAILLANE + '弄' END) + (CASE MAILOF WHEN '' THEN MAILNUM + '號' ELSE MAILNUM + '-' + MAILOF + '號' END) + (CASE MAILFLR WHEN '' THEN '' ELSE MAILFLR + '樓' END) + MAILETC WHEN '2' THEN MAILADD WHEN '3' THEN (CASE HOMEADDFLAG WHEN '1' THEN HOMECITY + HOMEAREA + HOMEVIL + HOMESTREET + (CASE HOMELANE WHEN '' THEN '' ELSE HOMELANE + '巷' END) + (CASE HOMEALY WHEN '' THEN '' ELSE HOMELANE + '弄' END) + (CASE HOMEOF WHEN '' THEN HOMENUM + '號' ELSE HOMENUM + '-' + HOMEOF + '號' END) + (CASE HOMEFLR WHEN '' THEN '' ELSE HOMEFLR + '樓' END) + HOMEETC WHEN '2' THEN HOMEADD END) END) END LIVEADD, RARANK,RKYCTIME FROM CUST WHERE CID = ? AND SUBSTRING(REPLACE(RKYCTIME,'-',''),0,9) <= ?";
		String str = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			pstmt.setString(2, date);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				str = rs.getString("BIRTHD") + "|" + rs.getString("BIRTHP") + "|" + rs.getString("MAILADD") + "|" + rs.getString("LIVEADD") + "||||" + rs.getString("RARANK") + "|" + rs.getString("RKYCTIME");
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return str;
	}
	
	public String getA2(String cId, String date, Connection con) {
//		String sql = "SELECT TOP 1 RARANK,RKYCTIME FROM H_CUST WHERE CID = ? AND SUBSTRING(REPLACE(RKYCTIME,'-',''),0,9) <= ? ORDER BY RKYCTIME DESC";
		String sql = "SELECT CASE BIRTHP WHEN '1' THEN 'TW' WHEN '2' THEN BIRTHPO END BIRTHP, CASE HOMEADDFLAG WHEN '1' THEN HOMECITY + HOMEAREA + HOMEVIL + HOMESTREET + (CASE HOMELANE WHEN '' THEN '' ELSE HOMELANE + '巷' END) + (CASE HOMEALY WHEN '' THEN '' ELSE HOMELANE + '弄' END) + (CASE HOMEOF WHEN '' THEN HOMENUM + '號' ELSE HOMENUM + '-' + HOMEOF + '號' END) + (CASE HOMEFLR WHEN '' THEN '' ELSE HOMEFLR + '樓' END) + HOMEETC WHEN '2' THEN HOMEADD END HOMEADD, CASE LIVEADDFLAG WHEN '1' THEN 'TW' WHEN '2' THEN LIVEO WHEN '4' THEN (CASE MAILADDFLAG WHEN '1' THEN 'TW' WHEN '2' THEN MAILO END) WHEN '5' THEN (CASE HOMEADDFLAG WHEN '1' THEN 'TW' WHEN '2' THEN HOMEO END) END LIVEADD, RARANK,RKYCTIME FROM CUST WHERE CID = ? AND SUBSTRING(REPLACE(RKYCTIME,'-',''),0,9) <= ?";
		String str = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			pstmt.setString(2, date);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				str = "||||" + rs.getString("BIRTHP") + "|" + rs.getString("HOMEADD") + "|" + rs.getString("LIVEADD") + "|" + rs.getString("RARANK") + "|" + rs.getString("RKYCTIME");
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return str;
	}
	
	public Map<Integer, String> getStr(Connection con) {
		String sql = "SELECT BRANCH, UID, EDITTIME, CID, NAME, COMT, COMTO, LTD, COMBS, COMBSP, SHBS, SHBSP, ACCCLSMARK FROM CUST WHERE IDTYPE = '02'";
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("BRANCH") + "|" + rs.getString("UID") + "|" + rs.getString("EDITTIME") + "|" + rs.getString("CID") + "|" + rs.getString("NAME") + "|" + rs.getString("COMT") + "|" + rs.getString("COMTO") + "|" + rs.getString("LTD") + "|" + rs.getString("COMBS") + "|" + rs.getString("COMBSP") + "|" + rs.getString("SHBS") + "|" + rs.getString("SHBSP") + "|" + rs.getString("ACCCLSMARK") + "\r\n");
				cnt++;
			}
		} catch (SQLException sqlE) {			
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	/*public Map<Integer, String> get90700647(Connection con) {
		String sql = "SELECT CID, EMAIL FROM CUST WHERE IDTYPE = '01' AND EMAIL != '' AND EMAIL != '@' AND ACCCLSMARK != '1' AND BIRTHD >= CONVERT(VARCHAR(4), CONVERT(char(4), GETDATE(), 112)-55)+'-01-01' AND BIRTHD < CONVERT(VARCHAR(4), CONVERT(char(4), GETDATE(), 112)-25)+'-01-01' AND BRFLAG !='16' AND BRFLAG != '21' AND BRFLAG !='16,21' AND BRFLAG != '21,16'";
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("CID") + "|" + rs.getString("EMAIL") + "\r\n");
				cnt++;
			}
		} catch (SQLException sqlE) {			
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}*/
	
	public String get90700647(String date, FileWriter fw, File file, Connection con) {
		String sql = "SELECT CID, EMAIL FROM CUST WHERE IDTYPE = '01' AND EMAIL != '' AND EMAIL != '@' AND ACCCLSMARK != '1' AND BIRTHD >= CONVERT(VARCHAR(4), CONVERT(char(4), GETDATE(), 112)-55)+'-01-01' AND BIRTHD < CONVERT(VARCHAR(4), CONVERT(char(4), GETDATE(), 112)-25)+'-01-01' AND BRFLAG !='16' AND BRFLAG != '21' AND BRFLAG !='16,21' AND BRFLAG != '21,16'";
		String str = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				writeOut(fw,date + "|" + rs.getString("CID") + "|" + rs.getString("EMAIL"), file);
//				str += rs.getString("CID") + "|" + rs.getString("EMAIL") + "\r\n";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return str;
	}
	
	private static void writeOut(FileWriter fw, String line, File file) {
		try {
			if(fw == null) {
				fw = new FileWriter(file, true);
			}			
		} catch (IOException e) {
			e.printStackTrace();
		}
		PrintWriter pw = new PrintWriter(fw);
		pw.println(line);
		pw.flush();
		try {
			fw.flush();
			fw.close();
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	/*public CustVo findPrin(String cId, Connection con) {
		String sql = "SELECT CUST.CID, CUST.NAME, CUST.EDITTIME, CASE WHEN TRIM(POS) = '董事長' THEN '董事長：'+HM.NAME WHEN TRIM(POS) = '負責人' THEN '負責人：'+HM.NAME ELSE '' END'PRINCIPLE',CASE WHEN TRIM(POS) = '總經理' THEN '總經理：'+HM.NAME ELSE '' END'MANAGER' FROM CUST, HM WHERE (TRIM(POS) = '董事長' OR TRIM(POS) = '負責人' OR TRIM(POS) = '總經理') AND CUST.CID = HM.CID AND CUST.CID = ?";
		CustVo cVo = new CustVo();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				cVo.setCId(rs.getString("CID"));
				cVo.setName(rs.getString("NAME"));
				cVo.setEditTime(rs.getString("EDITTIME"));
				cVo.setPosName(((cVo.getPosName() != null) ? cVo.getPosName() + "|" : "") + rs.getString("MANAGER") + rs.getString("PRINCIPLE"));
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return cVo;		
	}*/
	
	/*public String getPrinciple(String cId, Connection con) {
		String sql = "SELECT CUST.CID, CUST.NAME, CUST.EDITTIME, CASE WHEN TRIM(POS) = '董事長' THEN HM.NAME WHEN TRIM(POS) = '負責人' THEN HM.NAME ELSE '' END'PRINCIPLE',CASE WHEN TRIM(POS) = '總經理' THEN HM.NAME ELSE '' END'MANAGER' FROM CUST, HM WHERE (TRIM(POS) = '董事長' OR TRIM(POS) = '負責人' OR TRIM(POS) = '總經理') AND CUST.CID = HM.CID AND CUST.CID = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String str = "";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				str += rs.getString("CID") + "|" + rs.getString("NAME") + "|" + rs.getString("EDITTIME") + "|" + rs.getString("PRINCIPLE") + "|" + rs.getString("MANAGER");
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return str;		
	}*/

	public CustVo findPrin(String cId, Connection con) {
		String sql = "SELECT CUST.CID, CUST.NAME, CUST.EDITTIME, CASE WHEN TRIM(POS) = '董事長' THEN HM.NAME WHEN TRIM(POS) = '負責人' THEN HM.NAME ELSE '' END'PRINCIPLE' FROM CUST, HM WHERE (TRIM(POS) = '董事長' OR TRIM(POS) = '負責人') AND CUST.CID = HM.CID AND CUST.CID = ?";
		CustVo cVo = new CustVo();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				cVo.setCId(rs.getString("CID"));
				cVo.setName(rs.getString("NAME"));
				cVo.setEditTime(rs.getString("EDITTIME"));
				cVo.setPosName(rs.getString("PRINCIPLE"));
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return cVo;		
	}
	
	public String findHId(String cId, Connection con) {
		String sql = "SELECT MAX(RKYCTIME) AS RKYCTIME FROM H_CUST WHERE CID = ? AND RDDLCONN != '' GROUP BY CID ORDER BY CID, RKYCTIME ASC";
		String str = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				str = rs.getString("RKYCTIME");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return str;
	}
	
	public CustVo findMana(String cId, Connection con) {
		String sql = "SELECT CUST.CID, CUST.NAME, CUST.EDITTIME, CASE WHEN TRIM(POS) = '總經理' THEN HM.NAME ELSE '' END'MANAGER' FROM CUST, HM WHERE (TRIM(POS) = '總經理') AND CUST.CID = HM.CID AND CUST.CID = ?";
		CustVo cVo = new CustVo();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				cVo.setCId(rs.getString("CID"));
				cVo.setName(rs.getString("NAME"));
				cVo.setEditTime(rs.getString("EDITTIME"));
				cVo.setPosName(rs.getString("MANAGER"));
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return cVo;		
	}
	
	public Map<String, String> getM01(Connection con) {
		String sql = "SELECT CID FROM ACC14M01 WHERE CID NOT IN (SELECT CID FROM ACC14)";
		Map<String, String> map = new HashMap<String, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(rs.getString("CID"),"");
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public boolean existGCIS(String cId, Connection con) {
		boolean r = false;
		String sql = "SELECT TOP 1 1 FROM CUST WHERE CID = ? AND ACCCLSMARK != '1'";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				r = true;
			}
		} catch (SQLException sqlE) {
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			if(rs != null) {
				try {
					rs.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException sqlE) {
					sqlE.printStackTrace();
				}
			}
		}
		return r;		
	}
	
	public CustVo findGCISKYC(String cId, Connection con) {
		String sql = "SELECT CID, [NAME], RMDBRANCH,BRFLAG FROM CUST WHERE CID = ?";
		CustVo cVo = new CustVo();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				cVo.setCId(rs.getString("CID"));
				cVo.setName(rs.getString("NAME"));
				cVo.setRmdBranch(rs.getString("RMDBRANCH"));
				cVo.setBRFlag(rs.getString("BRFLAG"));
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return cVo;		
	}
}