package com.ubot.kyc.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ThretRISDao {
	public Map<Integer, String> getThret(Connection con) {
		String sql = "SELECT THRET_ID_NO FROM THRETRIS WHERE DAILYDATE = CONVERT(varchar(10), GETDATE(), 23) AND ACCCLSMARK != '1' AND THRET_YN = 'Y' AND REPORT_YN = 'Y' ORDER BY DAILYDATE ASC";
//		String sql = "SELECT THRET_ID_NO FROM THRETRIS WHERE DAILYDATE = '2024-07-25' AND ACCCLSMARK != '1' AND THRET_YN = 'Y' AND REPORT_YN = 'Y' ORDER BY DAILYDATE ASC";
		
		Map<Integer, String> map = new HashMap<Integer, String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int cnt = 0;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				map.put(cnt,rs.getString("THRET_ID_NO"));
				cnt++;
			}
		} catch (SQLException sqlE) {			
			sqlE.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}
		return map;
	}
	
	public ThretRISVo findById(String cId, Connection con) {
		String sql = "SELECT THRET_ID_NO, NAME, RMDBRANCH, BRFLAG, DAILYDATE, ACCBRANCH FROM THRETRIS WHERE THRET_ID_NO = ? AND DAILYDATE = CONVERT(varchar(10), GETDATE(), 23) AND THRET_YN = 'Y' AND ACCCLSMARK != '1'";
//		String sql = "SELECT THRET_ID_NO, NAME, RMDBRANCH, BRFLAG, DAILYDATE, ACCBRANCH FROM THRETRIS WHERE THRET_ID_NO = ? AND DAILYDATE = '2024-07-25' AND THRET_YN = 'Y' AND ACCCLSMARK != '1'";

		ThretRISVo vo = new ThretRISVo();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while (rs.next()) {		
				vo.setThret_Id_No(rs.getString("THRET_ID_NO"));
				vo.setName(rs.getString("NAME"));
				vo.setRmdBranch(rs.getString("RMDBRANCH"));
				vo.setBrFlag(rs.getString("BRFLAG"));
				vo.setDailyDate(rs.getString("DAILYDATE"));
				vo.setAccBranch(rs.getString("ACCBRANCH"));
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return vo;	
	}
	
	public String getDate(String cId, Connection con) {
		String sql = "SELECT TOP 1 DAILYDATE FROM THRETRIS WHERE THRET_ID_NO = ? AND THRET_YN = 'Y' ORDER BY DAILYDATE ASC";
		String str = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				str = rs.getString("DAILYDATE");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs!= null) {
				try {
					rs.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {					
					e.printStackTrace();
				}
			}
		}	
		return str;
	}
	
	public List<String> getList2(Connection con) {
		String sql = "SELECT THRET_ID_NO FROM THRETRIS WHERE DAILYDATE = CONVERT(varchar(10), GETDATE(), 23) AND THRET_YN = 'Y' AND ACCCLSMARK != '1'";
		List<String> list = new ArrayList<String>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				list.add(rs.getString("THRET_ID_NO"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(con != null) {
				try {
					con.close();
				} catch (SQLException e) {						
					e.printStackTrace();
				}
			}
		}
		return list;
	}
}
