package com.ubot.kyc.db;

public class ThretRISVo {
	private String thret_Id_No;
	private String name;
	private String thret_24Mon;
	private String thret_30Mon;
	private String thret_24Val;
	private String thret_30Val;
	private String thret_YN;
	private String dailyDate;
	private String idType;
	private String raRank;
	private String accClsMark;
	private String editTime;
	private String rmdBranch;
	private String brFlag;
	private String report_YN;
	private String rareason;
	private String jointNY;
	private String bankTagNY;
	private String thret_Acc_No;
	private String accBranch;
	
	public String getThret_Id_No() {
		return thret_Id_No;
	}
	
	public void setThret_Id_No(String thret_Id_No) {
		this.thret_Id_No = thret_Id_No;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getThret_24Mon() {
		return thret_24Mon;
	}
	
	public void setThret_24Mon(String thret_24Mon) {
		this.thret_24Mon = thret_24Mon;
	}
	
	public String getThret_30Mon() {
		return thret_30Mon;	
	}
	
	public void setThret_30Mon(String thret_30Mon) {
		this.thret_30Mon = thret_30Mon;
	}
	
	public String getThret_24Val() {
		return thret_24Val;
	}
	
	public void setThret_24Val(String thret_24Val) {
		this.thret_24Val = thret_24Val;
	}
	
	public String getThret_30Val() {
		return thret_30Val;
	}
	
	public void setThret_30Val(String thret_30Val) {
		this.thret_30Val = thret_30Val;
	}
	
	public String getThret_YN() {
		return thret_YN;
	}
	
	public void setThret_YN(String thret_YN) {
		this.thret_YN = thret_YN;
	}
	
	public String getDailyDate() {
		return dailyDate;
	}
	
	public void setDailyDate(String dailyDate) {
		this.dailyDate = dailyDate;
	}
	
	public String getIdType() {
		return idType;
	}
	
	public void setIdType(String idType) {
		this.idType = idType;
	}
	
	public String getRaRank() {
		return raRank;
	}
	
	public void setRaRank(String raRank) {
		this.raRank = raRank;
	}
	
	public String getAccClsMark() {
		return accClsMark;
	}
	
	public void setAccClsMark(String accClsMark) {
		this.accClsMark = accClsMark;
	}
	
	public String getEditTime() {
		return editTime;
	}
	
	public void setEditTime(String editTime) {
		this.editTime = editTime;
	}
	
	public String getRmdBranch() {
		return rmdBranch;
	}
	
	public void setRmdBranch(String rmdBranch) {
		this.rmdBranch = rmdBranch;
	}
	
	public String getBrFlag() {
		return brFlag;
	}
	
	public void setBrFlag(String brFlag) {
		this.brFlag = brFlag;
	}

	public String getReport_YN() {
		return report_YN;
	}

	public void setReport_YN(String report_YN) {
		this.report_YN = report_YN;
	}

	public String getRareason() {
		return rareason;
	}

	public void setRareason(String rareason) {
		this.rareason = rareason;
	}

	public String getJointNY() {
		return jointNY;
	}

	public void setJointNY(String jointNY) {
		this.jointNY = jointNY;
	}

	public String getBankTagNY() {
		return bankTagNY;
	}

	public void setBankTagNY(String bankTagNY) {
		this.bankTagNY = bankTagNY;
	}

	public String getThret_Acc_No() {
		return thret_Acc_No;
	}

	public void setThret_Acc_No(String thret_Acc_No) {
		this.thret_Acc_No = thret_Acc_No;
	}

	public String getAccBranch() {
		return accBranch;
	}

	public void setAccBranch(String accBranch) {
		this.accBranch = accBranch;
	}
}
